<script>
  export default {
    name: "PostManageView",
    data () {
      return {
        username: "",
        pageNum: 1,
        pageSize: 2,
        tableData: [],
        total: 0
      }
    },
    created() { // 页面一创建就执行的动作
      // 请求分页查询数据
      this.loadData()
    },
    methods: {
      loadData() {
        // this.request.get('/user/page', {
        //   params: {
        //     pageNum: this.pageNum,
        //     pageSize: this.pageSize,
        //     username: this.username
        //   }
        // }).then(res => {
        //   this.tableData = res.records
        //   this.total = res.total
        // })
      },
      handleSizeChange(pageSize) {
        this.pageSize = pageSize
        this.loadData()
      },
      handleCurrentChange(pageNum) {
        this.pageNum = pageNum
        this.loadData()
      }
    }
  }
</script>

<template>
  <div>
    <div style="margin: 10px 0">
      <el-input style="width: 300px" placeholder="请输入名称" v-model="username"></el-input>
      <el-button style="margin-left: 5px" type="primary" icon="el-icon-search" @click="loadData">搜索</el-button>
    </div>

    <div style="margin: 10px 0">
      <el-button type="primary" icon="el-icon-plus">创建新文章</el-button>
      <!-- <el-button type="danger" icon="el-icon-minus">批量删除</el-button> -->
      <el-button type="primary" icon="el-icon-download">导入</el-button>
      <el-button type="primary" icon="el-icon-upload">导出</el-button>
    </div>

    <el-table :data="tableData" border stripe>
      <el-table-column prop="id" label="ID"></el-table-column>
      <el-table-column prop="username" label="文章标题"></el-table-column>
      <el-table-column prop="name" label="发布者"></el-table-column>
      <el-table-column prop="email" label="描述"></el-table-column>
      <el-table-column prop="operation" label="操作">
        <template slot-scope="scope">
          <el-button type="success" icon="el-icon-edit">编辑</el-button>
          <el-button type="danger" icon="el-icon-delete">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div style="padding: 10px 0">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pageNum"
          :page-sizes="[2, 4, 6, 8]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total">
      </el-pagination>
    </div>
  </div>
</template>

<style scoped>

</style>