<template>
    <div class="article-editor">
      <el-form :model="articleForm" label-width="120px">
        <!-- 文章标题 -->
        <el-form-item label="文章标题">
          <el-input v-model="articleForm.title" placeholder="请输入文章标题"></el-input>
        </el-form-item>
  
        <!-- 文章内容 (Markdown 编辑器) -->
        <el-form-item label="文章内容">
            <div><mavon-editor ref="md" v-model="articleForm.content" :ishljs="true"/></div>
        </el-form-item>
  
        <!-- 保存按钮 -->
        <el-form-item>
          <el-button type="primary" @click="saveArticle">保存文章</el-button>
          <el-button @click="resetForm">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </template>
  
  <script>
  // @imgAdd="imgAdd"
  
  export default {
    components: {
    },
    data() {
      return {
        articleForm: {
          title: '',
          content: ''
        }
      };
    },
    methods: {
      // 保存文章方法
      saveArticle() {
        if (!this.articleForm.title || !this.articleForm.content) {
          this.$message.error('请填写完整的文章信息');
          return;
        }
        // 这里可以发送保存文章的请求，比如：
        // this.$request.post('/api/articles', this.articleForm).then(...)
        console.log('保存文章:', this.articleForm);
        this.$message.success('文章已保存');
      },
  
      // 重置表单
      resetForm() {
        this.articleForm.title = '';
        this.articleForm.content = '';
      }
    }
  };
  </script>
  
  <style scoped>
  .article-editor {
    padding: 20px;
  }
  </style>
  