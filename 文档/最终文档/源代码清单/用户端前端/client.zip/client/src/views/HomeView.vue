<template>
  <div :style="{ backgroundImage: `url(${require('../assets/a.jpg')})`, backgroundSize: 'cover', height: '100vh', display: 'flex', flexDirection: 'column', justifyContent: 'space-around', alignItems: 'center' }">
    <!-- 标题和副标题 -->
    <div style="text-align: center; color: white;">
      <h1 style="font-size: 48px; font-weight: bold;">欢迎来到我们的博客</h1>
      <p class="subline" style="font-size: 18px;">welcome</p>
    </div>

    <!-- 按钮导航栏 -->
    <div style="margin-top: 20px;">
      <el-button type="text" @click="$router.push('/post')" class="nav-button">
        文章
      </el-button>
      <el-button type="text" @click="$router.push('/about')" class="nav-button">
        关于
      </el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HomeView'
}
</script>

<style scoped>
/* 调整按钮的基础样式 */
.nav-button {
  color: white;
  font-size: 18px;
  padding: 10px 20px;
  border-radius: 0px;
  /* transition: background 0.3s ease; */
  display: inline-block; /* 让按钮紧挨在一起 */
  margin: 0; /* 移除默认的按钮间距 */
}

/* 按钮悬停时的渐变色效果：从下往上渐变 */
.nav-button:hover {
  background: linear-gradient(to top, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0)); /* 从白色到透明的渐变 */
  color: white;
}
</style>
