<template>
  <div class="article-detail" v-loading="loading">
    <!-- <el-page-header @back="goBack" content="详情页面"></el-page-header> -->
    <!-- 文章头图 -->
    <img
      :src="article.imgUrl ?? 'https://fuss10.elemecdn.com/a/3f/3302e58f9a181d2509f3dc0fa68b0jpeg.jpeg'"
      alt="Article Header Image"
      class="article-header-image"
    />

    <div class="article-content">
      <!-- 文章标题 -->
      <h1 class="article-title">{{ article.title }}</h1>

      <!-- 作者和发布时间 -->
      <div class="article-meta">
        <span class="article-author">
          <i class="el-icon-user"></i> {{ article.author }}
        </span>
        <span class="article-time">
          <i class="el-icon-time"></i> {{ formatTime(article.createdTime) }}
        </span>
      </div>

      <!-- 文章内容 -->
<!--      <div class="article-body" v-html="article.content"></div>-->
      <mavon-editor
          class="md"
          :value="article.content"
          :subfield="false"
          :defaultOpen="'preview'"
          :toolbarsFlag="false"
          :editable="false"
          :scrollStyle="true"
          :ishljs="true"
      />
    </div>

    <div class="thumb-for">
      <!-- thumbs-count传递的是点赞的数量，thumbs-up-flag传递的是当前用户是否点赞的标识 -->
      <thumb-up
        :thumbs-count="article.likeNum"
        :thumbs-up-flag="false"
      ></thumb-up>
    </div>

    <!-- 评论区 -->
    <comment-section :comments="article.comments" :articleId="this.$route.params.id" @comment-added="updateComments"></comment-section>
  
  </div>
</template>

<script>
import { getArticleById } from '@/api/article';
import thumbUp from '@/components/thumb-up.vue';
import CommentSection from '@/components/CommentSection.vue';

export default {
  name: 'DetailView',
  components: {
    thumbUp,
    CommentSection,
  },
  data() {
    return {
      article: {},
      loading: false
    };
  },
  created() {
    const articleId = this.$route.params.id;
    // 模拟获取文章详情
    this.loading = true;
    getArticleById(articleId).then((response) => {
      this.loading = false;
      this.article = response.data;
      this.article.comments.reverse();
      console.log(this.article)
    }).catch((err) => {
        this.$message({
          showClose: true,
          message: '警告：获取文章数据时发生错误：' + err.message,
          type: 'error'
        });
      });
  },
  methods: {
    updateComments(updatedComments) {
      this.article.comments = updatedComments; // 更新评论
    },
    formatTime(date) {
      const d = new Date(date);
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      const hours = String(d.getHours()).padStart(2, '0');
      const minutes = String(d.getMinutes()).padStart(2, '0');

      return `${year}-${month}-${day} ${hours}:${minutes}`;
    },
  },
};
</script>

<style scoped>
.article-detail {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  
  color: #333;
  line-height: 1.7;
  text-align: justify;
}

.article-header-image {
  width: 100%;
  height: auto;
  margin-bottom: 20px;
}

.article-title {
  font-size: 32px;
  font-weight: bold;
  margin-bottom: 10px;
}

.article-meta {
  font-size: 14px;
  color: #666;
  margin-bottom: 20px;
}

.article-author,
.article-time {
  margin-right: 20px;
}

.article-body {
  font-size: 16px;
  line-height: 1.6;
  color: #333;
}

.thumb-for {
  text-align: center;
  margin-bottom: 30px;
  margin-top: 20px;
}
</style>
