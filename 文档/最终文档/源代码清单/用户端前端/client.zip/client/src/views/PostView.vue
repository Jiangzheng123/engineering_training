<template>
  <el-container style="padding: 0 10%">
    <el-main>
      <!-- 搜索栏 -->
      <div style="margin: 10px 0">
        <el-input
          style="width: 300px"
          placeholder="输入文章名称"
          v-model="searchName"
        ></el-input>
        <el-button
          style="margin-left: 5px"
          type="primary"
          icon="el-icon-search"
          @click="searchClicked"
          >搜索</el-button
        >
      </div>

      <tag-filter :tags="tags" @filter="tagChanged" :loading="loadingTags"></tag-filter>

      <article-list
        :articles="curPageArticles"
        :pageSize="pageSize"
        :startNum="startNum"
        :loading="loading"
      ></article-list>
    </el-main>
    <el-footer>
      <div style="padding: 0 0">
        <el-pagination
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-size="pageSize"
          layout="total, prev, pager, next, jumper"
          :total="totalArticles"
        >
        </el-pagination>
      </div>
    </el-footer>
  </el-container>
</template>

<script>
import TagFilter from '@/components/TagFilter.vue';
import ArticleList from '@/components/ArticleList.vue'; // 导入 ArticleList 组件
import { fetchArticleList, getAllLabels } from '@/api/article';

export default {
  name: 'PostView',
  components: {
    TagFilter,
    ArticleList, // 注册 ArticleList 组件
  },
  data() {
    return {
      // 文章总数
      totalArticles: 1,
      // 单页大小
      pageSize: 3,
      // 当前页号
      currentPage: 1,
      // 按序号存放文章数据
      // articles: [],
      // 所有tag数据
      tags: [],
      curPageArticles: [],
      searchName: '',
      selectedTag: 'all',
      searchedTitle: '',
      loading: false,
      loadingTags: false,
    };
  },
  computed: {
    // 总展示页数
    totalPage() {
      return Math.ceil(this.totalArticles / this.pageSize);
    },
    // 本页第一篇文章的序号
    startNum() {
      return (this.currentPage - 1) * this.pageSize;
    },
  },
  created() {
    // 加载标签列表
    this.loadingTags = true;
    getAllLabels().then(
      (res) => {
        this.tags = res.data;
        this.loadingTags = false;
      },
      (err) => {
        console.log(err);
        this.loadingTags = false;
      }
    ).catch((err) => {
        this.$message({
          showClose: true,
          message: '警告：获取文章标签列表发生错误：' + err.message,
          type: 'error'
        });
      });
    // 加载文章列表
    this.refreshArticlesList();
  },
  methods: {
    searchClicked() {
      this.searchedTitle = this.searchName;
      this.refreshArticlesList();
      this.$message({
        showClose: true,
        message: '搜索成功',
        type: 'success'
      });
    },
    // 根据分页查询文章列表
    refreshArticlesList() {
      this.loading = true;
      fetchArticleList({
        page: this.currentPage - 1, // 当前页
        size: this.pageSize, // 总页数
        title: this.searchedTitle.trim() ? this.searchedTitle : undefined,
        tagId: this.selectedTag !== 'all' ? this.selectedTag : undefined,
      }).then((res) => {
        this.totalArticles = res.data.total;
        this.curPageArticles = res.data.records;
        this.loading = false;
        // res.data.forEach((item, i) => {
        //   // 读入文章数据
        //   this.articles[res.startNum + i] = item;
        // });
      }).catch((err) => {
        this.$message({
          showClose: true,
          message: '警告：获取文章列表发生错误：' + err.message,
          type: 'error'
        });
      })
      ;
    },
    handleCurrentChange(currentPage) {
      this.currentPage = currentPage;
      this.refreshArticlesList();
    },
    tagChanged(selectedTags) {
      if (selectedTags.includes('all')) {
        this.selectedTag = 'all';
      } else {
        this.selectedTag = selectedTags?.[0] ?? 'all';
      }
      this.refreshArticlesList();
      // this.applyFilter();
    },
    // applyFilter() {
    //   // console.log(this.selectedTags)
    //   // 根据选中的标签id过滤文章
    //   if (this.selectedTag.includes('all')) {
    //     this.curPageArticles = this.articles;
    //   } else {
    //     this.curPageArticles = this.articles.filter((article) =>
    //       article.labels.some((label) => this.selectedTag.includes(label.id))
    //     );
    //   }
    //   this.totalArticles = this.curPageArticles.length;
    // },
  },
};
</script>
