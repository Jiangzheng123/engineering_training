<template>
  <div :style="backgroundStyle" class="about-container">
    <div class="about-content">
      <h1>关于本项目</h1>
      <p>
        本项目是卓越工程小组项目——个人博客系统。由临时组成的5人开发小组完成。
      </p>
      <p>
        由于我们组中有3人考研，大家时间比较紧迫，可用在开发的时间并不充裕。经过几周的敏捷开发，从需求分析、系统设计，到后面的相关前后端技术学习（js+vue、java+SpringBoot），再到编码实现、测试、部署上线等阶段，最终完成了一个功能完善的个人博客系统。
      </p>
      <p>
        尽管中途遇到了各种困难，不管是技术上的，还是团队协作上的，我们还是坚持了下来，完成了这个项目。当成品最终落地实现，我们仍然感到由衷的自豪。
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AboutView',
  computed: {
    backgroundStyle() {
      return {
        backgroundImage: `url(${require('../assets/1.jpeg')})`,
        backgroundSize: 'cover',
        height: '97vh',
      };
    }
  }
}
</script>

<style scoped>
.about-container {
  display: flex;
  justify-content: center;
  align-items: center;
  color: white;
  padding: 0;
  margin: 0;
}

.about-content {
  background: rgba(0, 0, 0, 0.7);
  border-radius: 10px;
  padding: 40px;
  max-width: 800px;
  text-align: center;
}

.about-content h1 {
  font-size: 36px;
  font-weight: bold;
}

.about-content p {
  font-size: 18px;
  margin-top: 20px;
}
</style>
