<template>
  <div class="manage" style="height: 100%">
    <!-- <el-aside :width="asideWidth + 'px'" style="background-color: rgb(238, 241, 246); height: 100%">
    </el-aside> -->

    <el-container>
      <el-header style="border-bottom: 1px solid #cccccc">
        <Header :collapse-btn-class="collapseBtnClass" :collapse="collapse"></Header>
      </el-header>

      <el-main style="padding: 0; margin: 0;">
        <!-- 表示当前页面的子路由会在此展示 -->
        <router-view></router-view>
      </el-main>
    </el-container>
  </div>
</template>

<script>
  import Aside from "@/components/Aside.vue";
  import Header from "@/components/Header.vue";

  export default {
    name: 'ManageView',
    data() {
      return {
        isCollapse: false,
        asideWidth: 200,
        collapseBtnClass: "el-icon-s-fold",
        logoTextShow: true
      }
    },
    methods: {
      collapse() {
        this.isCollapse = !this.isCollapse;
        this.logoTextShow = !this.logoTextShow;
        if(this.isCollapse){
          this.asideWidth = 65;
          this.collapseBtnClass = "el-icon-s-unfold";
        }else{
          this.asideWidth = 200;
          this.collapseBtnClass = "el-icon-s-fold";
        }
      }
    },
    components: {
      Aside,
      Header
    }
  }
</script>
