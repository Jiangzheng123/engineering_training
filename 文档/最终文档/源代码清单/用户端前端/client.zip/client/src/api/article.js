// import request from '@/utils/request'

const allTags = [
  { id: 1, name: 'Vue.js' },
  { id: 2, name: 'React' },
  { id: 3, name: 'Node.js' },
  { id: 4, name: 'JavaScript' },
  { id: 5, name: 'CSS' },
  { id: 6, name: 'HTML' },
  { id: 7, name: 'Python' },
  { id: 8, name: 'Java' },
  { id: 9, name: 'C++' },
  { id: 10, name: 'PHP' },
  // { id: 11, name: 'Go' },
];

const commentList = [
  {
    id: 1,
    name: '小明',
    createdTime: '2024-10-23',
    content: '这篇文章写得很好！',
    children: [
      {
        id: 3,
        name: '小明',
        createdTime: '2024-10-23',
        content: '你说的对',
      },
      {
        id: 4,
        name: '小红',
        createdTime: '2024-10-24',
        content: '确实',
      },
    ]
  },
  {
    id: 2,
    name: '小红',
    createdTime: '2024-10-24',
    content: '我也觉得很不错！',
    children: []
  },
];

const mockArticle = (id) => {
  const tags = [allTags[Math.floor(Math.random() * allTags.length)]];
  return {
    id: id, // 主键，数字，自增
    title: `如何使用 ${tags.map((tag) => tag.name).join('、')} 开发应用`, // 文章标题，不为空，最长40个字符，唯一
    introduction: '本文介绍了使用 Vue.js 开发应用的基本步骤和注意事项。', // 文章简介，最长200个字符version: 1,                          // 文章版本号，不为空，默认为1
    browseNum: 0, // 浏览数，不为空，默认为0
    commentNum: 2, // 评论数，不为空，默认为0
    likeNum: 0, // 点赞数，不为空，默认为0
    shareNum: Math.floor(Math.random() * 1000), // 分享数，不为空，默认为0
    heat: Math.floor(Math.random() * 1000), // 文章热度，不为空，默认为0
    createdTime: new Date(), // 创建时间，自动填充

    // author: '张三',

    content: `本文id：${id}。\n在本文中，我们将探讨如何使用 Vue.js 来构建一个现代化的前端应用。Vue.js 是一个渐进式的 JavaScript 框架，具有轻量级和灵活性的特点。我们将涵盖安装 Vue.js、创建组件、使用路由、以及状态管理等主题。`, // 文章文本内容

    // imgUrl: 'https://fuss10.elemecdn.com/a/3f/3302e58f9a181d2509f3dc0fa68b0jpeg.jpeg', // 文章封面图片，不为空
    // 随机tags
    labels: tags,
    comments: [...commentList],
  };
};

const mockArticleList = Array.from({ length: 30 }, (_, i) =>
  mockArticle(i + 1)
);

/**
 * 模拟 request 请求
 * @returns
 */
const mockRequest = ({ url, method, data }) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      
    if (method === 'get' && url === '/client/label') {
      resolve({ data: allTags });
    } else if (method === 'get' && url.startsWith('/client/pageArticle')) {
      const params = new URLSearchParams(url.split('?')[1]);
      const page = parseInt(params.get('page')) || 0;
      const size = parseInt(params.get('size')) || 10;
      const title = params.get('title') || '';
      const tagId = params.get('tagId');

      // 根据 title 和 tagId 筛选文章
      let filteredArticles = mockArticleList.filter((article) => {
        const matchesTitle = title ? article.title.includes(title) : true;
        const matchesTag = tagId
          ? article.labels.some((label) => label.id === parseInt(tagId))
          : true;
        return matchesTitle && matchesTag;
      });

      // 计算总数
      const total = filteredArticles.length;

      // 分页处理
      const index = (page - 0) * size;
      const records = filteredArticles.slice(index, index + size);

      resolve({
        data: {
          total,
          records,
        },
      });
    } else if (method === 'get' && url.startsWith('/client/article')) {
      const id = url.split('=').pop();
      // console.log(parseInt(id) - 1, mockArticleList[parseInt(id) - 1], mockArticleList)
      const origArticle = mockArticleList[parseInt(id) - 1];
      origArticle.browseNum += 1;
      const article = { ...origArticle};
      article.comments = [...article.comments]; // 深拷贝，避免修改原数据
      resolve({
        data: article,
      });
    } else if (method === 'post' && url === '/client/comment') {
      const { article_id, name, email, content } = data;
      const comment = {
        id: mockArticleList[article_id - 1].commentNum + 1,
        email,
        name,
        createdTime: new Date(),
        content,
      };
      mockArticleList[article_id - 1].commentNum += 1;
      mockArticleList[article_id - 1].comments.unshift(comment);
      resolve({ data: { success: true } });
    } else if (method === 'post' && url === '/client/like') {
      const { id, liked } = data;
      // console.log(id);
      const article = mockArticleList.find(
        (article) => article.id === parseInt(id)
      );
      article.likeNum += liked ? 1 : -1;
      resolve({ data: { likes: article.likeNum } });
    } else {
      reject('Unknown request');
    }
    }, Math.random() * 1000);
  });
};

import request from '@/utils/request'
// const request = mockRequest;

/**
 * 获取所有文章标签
 */
export function getAllLabels() {
  return request({
    url: `/client/label`,
    method: 'get',
  });
}

/**
 * 分页获取文章列表
 * @param {object} data 包含分页和筛选参数 { page (0开始), size, title, tagId }
 * @returns {Promise} 包含文章列表和总数的数据 {total, articles}
 */
export function fetchArticleList(data) {
  return request({
    url: `/client/pageArticle?page=${data.page}&size=${data.size}&title=${
      data.title ?? ''
    }&tagId=${data.tagId ?? ''}`,
    method: 'get',
  });
}

/**
 * 获取指定文章的详细内容
 * @param {number} id 文章ID
 */
export function getArticleById(id) {
  return request({
    url: `/client/article?id=${id}`,
    method: 'get',
  });
}

/**
 * 发布评论
 * @param {object} data 评论数据 { article_id, name, email, content }
 */
export function postComment(data) {
  return request({
    url: `/client/comment`,
    method: 'post',
    data: data,
  });
}

/**
 * 点赞或取消点赞文章
 * @param {object} data 包含文章ID和点赞状态 { id, liked }
 */
export function likeArticle(data) {
  return request({
    url: `/client/like`,
    method: 'post',
    data,
  });
}
