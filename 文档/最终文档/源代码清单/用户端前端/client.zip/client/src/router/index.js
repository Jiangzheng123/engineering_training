import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'manage',
    component: () => import(/* webpackChunkName: "about" */ '../views/ManageView.vue'),
    redirect: "/home",
    children: [
      {path: "user", name: "PostManageView", component: () => import('../views/PostManageView.vue')},
      // {path: "edit", name: "EditView", component: () => import('../views/EditView.vue')},
      {path: "post", name: "PostView", component: () => import('../views/PostView.vue')},
      {path: "about", name: "AboutView", component: () => import('../views/AboutView.vue')},
      {
        path: 'article/:id', // 添加文章详情路由
        name: 'ArticleDetail',
        component: () => import(/* webpackChunkName: "article-detail" */ '../views/DetailView.vue'),
        props: true // 通过 props 传递路由参数
      }
    ]
  },
  {
    path: '/home',
    name: 'home',
    component: () => import(/* webpackChunkName: "home" */ '../views/HomeView.vue')
  },
  // {
  //   path: '/about',
  //   name: 'about',
  //   // route level code-splitting
  //   // this generates a separate chunk (about.[hash].js) for this route
  //   // which is lazy-loaded when the route is visited.
  //   component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
  // },
  // {
  //   path: '/login',
  //   name: 'login',
  //   component: () => import('../views/LoginView.vue')
  // }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

// router.beforeEach((to, from, next) => {
//   const app = router.app; // 获取当前的 Vue 实例
//   app.showLoading(); // 显示加载动画
//   next();
// });

// router.afterEach(() => {
//   const app = router.app; // 获取当前的 Vue 实例
//   setTimeout(() => app.hideLoading(), 300); // 隐藏加载动画（延时可选）
// });

export default router
