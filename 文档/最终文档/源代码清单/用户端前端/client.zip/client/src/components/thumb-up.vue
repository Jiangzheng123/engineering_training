<template>
  <el-button 
    :type="isThumbsUp ? 'danger' : 'info'"
    @click="setArticleThumbUpById"
    round
    plain
  >
  <div style="display: flex; align-items: center;">
    <img src="../assets/like.svg" style="width: 25px; height: 25px;" />
    {{ isThumbsUp ? '已点赞' : '点赞' }} ({{ count }})
  </div>
  </el-button>
</template>

<script>
import { likeArticle } from '@/api/article';

export default {
  props: {
    thumbsCount: {
      type: Number,
      required: true
    },
    thumbsUpFlag: {
      type: Boolean,
      required: true
    }
  },
  name: 'thumb-up',
  data() {
    return {
      count: this.thumbsCount,
      isThumbsUp: this.thumbsUpFlag
    }
  },
  methods: {
    setArticleThumbUpById() {
      likeArticle({
        id: this.$route.params.id,
        liked: !this.isThumbsUp
      }).then(res => {
        const likes = res.data;
        this.isThumbsUp = !this.isThumbsUp;
        this.count = likes;
        this.$emit('thumbup', {
          count: this.count,
          isThumbsUp: this.isThumbsUp
        });
        if (this.isThumbsUp) {
          // this.count ++;
          this.$message.success('点赞成功');
        } else {
          // this.count --;
          // this.$message.info('取消点赞成功');
        }
      }).catch((err) => {
        this.$message({
          showClose: true,
          message: '警告：点赞时发生错误：' + err.message,
          type: 'error'
        });
      });
    }
  },
  watch: {
    thumbsCount(val) {
      this.count = val;
    }
  }
}
</script>

<style scoped>
.thumbUpAlready {
  background-color: #de686d;
  color: #fff !important;
}
</style>
