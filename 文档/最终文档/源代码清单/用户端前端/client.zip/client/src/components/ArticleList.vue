<template>
  <div v-loading="loading">
    <el-empty description="没找到文章哦~" v-if="!articles.length"></el-empty>
    <el-card
      :body-style="{ padding: '0px', height: '200px', display: 'flex' }"
      v-for="item in paginatedArticles"
      :key="item.id" 
      class="blog-card"
      shadow="hover"
    >
      <el-row type="flex" align="middle" style="width: 100%;"
      @click.native="goToArticle(item.id)">
        <!-- 左侧文章信息 -->
        <el-col :span="20" class="card-content">
          <div>
            <h1 class="card-title">{{ item.title }}</h1> <!-- 修改为 title -->
            <p class="card-description">{{ item.introduction }}</p> <!-- 修改为 introduction -->
          </div>

          <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 0px;">
            <!-- 左下角点赞、浏览、评论数量显示 -->
            <div class="article-stats" style="font-size: 14px;">
              <img src="../assets/like.svg" style="width: 25px; height: 25px; padding-top: 5px;" /> {{ item.likeNum }} 
              <i class="el-icon-view" style="margin-left: 10px; margin-right: 5px;"></i> {{ item.browseNum }} 
              <i class="el-icon-chat-dot-round" style="margin-left: 10px; margin-right: 5px;"></i> {{ item.commentNum }} 
            </div>

            <!-- 右下角作者和时间 -->
            <div style="font-size: 14px;">
              <i class="el-icon-user-solid"></i> <span>{{ item.author }}</span>
              <i class="el-icon-time" style="margin-left: 10px;"></i>
              <span>{{ formatTime(item.createdTime) }}</span> <!-- 修改为 createdTime -->
            </div>
          </div>
        </el-col>

        <!-- 右侧文章图片 -->
        <el-col :span="4" class="image-container">
          <img :src="item.imgUrl ?? 'https://fuss10.elemecdn.com/a/3f/3302e58f9a181d2509f3dc0fa68b0jpeg.jpeg'" class="image multi-content" />
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<script>
export default {
  name: 'ArticleList',
  props: {
    // 当前起始文章编号
    startNum: {
      type: Number,
      required: true,
    },
    pageSize: {
      type: Number,
      required: true,
    },
    articles: {
      type: Array,
      required: true,
    },
    loading: {
      type: Boolean,
      required: true,
    }
  },
  // data() {
  //   return {
  //     loading: false,
  //   };
  // },
  computed: {
    // 计算要展示的文章
    paginatedArticles() {
      // return this.articles.slice(this.startNum, this.startNum + this.pageSize);
      return this.articles;
    },
  },
  methods: {
    goToArticle(id) {
      console.log(id);
      this.$router.push('/article/' + id);
    },
    formatTime(date) {
      const d = new Date(date);
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0'); // 月份从0开始，需要加1
      const day = String(d.getDate()).padStart(2, '0');
      const hours = String(d.getHours()).padStart(2, '0');
      const minutes = String(d.getMinutes()).padStart(2, '0');
      
      return `${year}-${month}-${day} ${hours}:${minutes}`;
    }
  },
};
</script>

<style scoped>
.blog-card {
  border-radius: 8px;
  overflow: hidden;
  margin-bottom: 14px;
  margin-top: 14px;
  cursor: pointer;
}

.card-content {
  padding: 14px;
  display: flex;  
  height: 100%;
  flex-direction: column; /* 垂直排列子元素 */  
  justify-content: space-between; /* 在垂直方向上分配空间 */ 
}

.card-title {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 20px;
}

.card-description {
  font-size: 14px;
  color: #666;
  margin-bottom: 20px;
}

.image-container {
  text-align: right;
  height: 100%;
}

.image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
</style>
