<!-- Loading.vue -->
<template>
  <div class="loading-overlay">
    <div class="loader">加载中...</div>
  </div>
</template>

<script>
export default {
  name: 'Loading'
}
</script>

<style scoped>
.loading-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8); /* 半透明背景 */
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9998; /* 确保加载页面在最上层 */
}

.loader {
  font-size: 24px;
  font-weight: bold;
  color: white;
  z-index: 9999; /* 确保加载页面在最上层 */
  /* 可以使用CSS动画或SVG动画来美化 */
}
</style>
