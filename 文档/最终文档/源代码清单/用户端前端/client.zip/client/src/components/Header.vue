<script>
  export default {
    name: "Header",
    props: {
      // collapseBtnClass: String,
      // collapse: Function
    },
    data() {
      return {
      };
    },
    methods: {
      handleSelect(key, keyPath) {
        console.log(key, keyPath);
      }
    }
  }
</script>

<template>
  <div style="font-size: 12px; line-height: 60px; display: flex; justify-content: space-between; align-items: center;">
    <div style="flex: 1; font-size: 25px; display: flex; align-items: center;">
      <div style="height: 60px; line-height: 60px; display: flex; align-items: center;">
        <img src="../assets/logo.png" alt="" style="width: 20px; margin-right: 5px;">
        <!-- <b v-show="logoTextShow">个人博客系统</b> -->
      </div>

      <el-menu
        style="flex: 1; margin-left: 20px;"
        :collapse-transition="false"
        :default-active="$route.path"
        mode="horizontal"
        router
      >
        <el-menu-item index="/home">
          <i class="el-icon-s-home"></i>
          <span slot="title">主页</span>
        </el-menu-item>
        <!-- <el-menu-item index="/user">
          <i class="el-icon-document"></i>
          <span slot="title">文章管理</span>
        </el-menu-item> -->
        <el-menu-item index="/post">
          <i class="el-icon-document"></i>
          <span slot="title">文章</span>
        </el-menu-item>
        <el-menu-item index="/about">
          <i class="el-icon-phone-outline"></i>
          <span slot="title">关于</span>
        </el-menu-item>
      </el-menu>
    </div>

    <!-- <el-dropdown style="width: 70px; cursor: pointer;">
      <span>王小虎</span><i class="el-icon-arrow-down" style="margin-left: 5px;"></i>
      <el-dropdown-menu slot="dropdown" style="text-align: center;">
        <el-dropdown-item>个人信息</el-dropdown-item>
        <el-dropdown-item>
          <router-link to="/login" style="text-decoration: none; color: inherit;">退出</router-link>
        </el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown> -->
  </div>
</template>


<style scoped>

</style>