<template>
  <ul>
    <li v-if="commentList.length == 0">还没有人评论，留下第一条评论吧~</li>
    <li v-for="(comment, $key) in commentList">
      <div class="comment-detail">
        <img class="comment-detail-img" :src="comment.userPhoto ?? 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'" />
        <div class="comment-detail-body">
          <div class="comment-detail-body-top">
            <span class="detail-top-name"
              >{{ comment.name }} &nbsp;
              <!-- <span v-if="comment.id != null" class="bz-icon">博主</span> -->
            </span>
            <span class="detail-top-area"
              >&nbsp;&nbsp;{{ comment.area }} &nbsp;</span
            >
            <span style="float: right; color: #aaa"
              >{{ commentList.length - $key }}楼 &nbsp;{{ comment.createdTime }}</span
            >
          </div>
          <!-- <div v-if="comment.response" class="comment-detail-response">
            <h5>
              引用 {{ comment.responseName }}
              <font
                style="
                  font-size: 12px;
                  float: right;
                  color: #aaa;
                  font-weight: 400;
                "
                >发表时间： {{ comment.responseTime }}</font
              >
            </h5>
            {{ comment.response }}
          </div> -->
          <div
            v-html="comment.content"
            class="comment-detail-body-bottom"
          ></div>

          <!-- 回复按钮和回复输入框 -->
          <!-- <div>
            <el-button type="text" style="color: #aaa"  @click="toggleReply(comment.id)">回复</el-button>
          </div> -->
          <!-- <div v-if="isReplying === comment.id" class="reply-box">
            <el-input
              v-model="replyContent"
              placeholder="写下你的回复..."
              type="textarea"
              rows="3"
            ></el-input>
            <el-button type="primary" @click="submitReply(comment.id)">提交</el-button>
            <el-button  @click="toggleReply(null)">取消</el-button>
          </div> -->

          <!-- 如果有回复，递归调用 commentItem 展示楼中楼回复 -->
          <ul v-if="comment.children && comment.children.length" class="reply-list">
            <comment-list :comment-list="comment.children"></comment-list>
          </ul>
        </div>
      </div>
    </li>
  </ul>
</template>

<script>
export default {
  name: 'commentList',
  props: ['commentList'],
  data() {
    return {
      isReplying: null,  // 当前正在回复的评论ID
      replyContent: '',  // 回复内容
      // userData: {
      //   name: '漫漫长路',
      //   email: '946232976@qq.com'
      // }
    };
  },
  methods: {
    toggleReply(commentId) {
      this.isReplying = this.isReplying === commentId ? null : commentId;
      this.replyContent = '';  // 清空回复框内容
    },
    submitReply(commentId) {
      // 这里可以添加提交回复的逻辑，例如发送请求到服务器
      console.log(`回复评论ID ${commentId}：`, this.replyContent);
      this.toggleReply(null);  // 提交后收起回复框
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

.reply-box {
  /* margin-top: 10px; */
}

.reply-list {
  padding-left: 10px;
  border-left: 1px solid #eee;
  margin-top: 10px;
}

.comment-list {
  padding: 0px 10px;
}

.comment-detail-img {
  display: inline-block;
  width: 60px;
  height: 60px;
  border-radius: 50%;
  border: 1px solid #eee;
}

.detail-top-name {
  font-weight: 600;
  font-size: 16px;
  color: #333;
}

.comment-detail-body {
  display: inline-block;
  margin-left: 20px;
  flex: 1;
  /*position: absolute;*/
}

.comment-list-body ul {
  padding: 0px;
  position: relative;
}

.comment-list-body li {
  padding: 10px;
  border-bottom: 1px solid #eee;
}

.comment-detail-body-bottom {
  padding-bottom: 10px;
  color: #768390;
  padding-top: 8px;
  font-weight: 500;
  font-size: 16px;
}

.comment-detail {
  display: flex;
  position: relative;
  padding: 10px 0px;
}

.guide-comment {
  font-size: 16px;
  color: white;
  margin-bottom: 10px;
}

.guide-comment a {
  padding: 10px;
}

.comment-detail-foot {
  position: absolute;
  right: 0px;
  bottom: 0px;
}

.comment-detail-foot a {
  font-size: 12px;
  color: #2a2a2a;
  background: #fff;
  border-radius: 4px;
  /* border: 1px solid #de686d; */
  line-height: 30px;
  padding: 2px 5px;
}

.response-item-date {
  font-size: 12px;
  float: right;
  color: #aaa;
  font-weight: 400;
}

.comment-detail-response {
  background-color: #eee;
  /*min-height: 200px;*/
  padding: 10px;
  margin: 6px 10px;
  font-size: 14px;
  font-weight: 400;
  color: #888;
}

.comment-name::before {
  content: '*';
  position: absolute;
  left: -10px;
  top: 12px;
  color: rgb(199, 37, 78);
}

.detail-top-area {
  font-size: 12px;
  color: #999;
}

@media (max-width: 768px) {
  .comment-list {
    padding: 0px;
  }

  .comment-list-body li {
    padding: 2px 2px 8px 2px;
  }

  .comment-detail-body {
    margin-left: 0px;
    margin-bottom: 6px;
  }

  .comment-detail-img {
    width: 40px;
    height: 40px;
  }

  .comment-detail-body-top {
    padding-left: 10px;
  }

  .comment-detail-body-bottom {
    padding-left: 10px;
    padding-top: 6px;
  }

  .response-item-date {
    float: none;
    margin-left: 10px;
  }
}

@media (max-width: 540px) {
  .detail-top-area {
    display: none;
  }
}

li,
ul {
  list-style: none;
}

.bz-icon {
  font-size: 12px;
  background: #dc143c;
  color: #fff;
  opacity: 0.7;
  padding: 1px 4px;
  font-weight: 400;
  border-radius: 4px;
}
</style>
