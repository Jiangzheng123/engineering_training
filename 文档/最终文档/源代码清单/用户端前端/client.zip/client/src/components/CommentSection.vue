<template>
  <el-card class="comment-section">
    <h3>留下您的评论</h3>
    <!-- <el-divider content-position="left"><h3>留下您的评论</h3></el-divider> -->

    <div style="margin: 10px 0" v-loading="loading">
      <el-input
        type="text"
        placeholder="您的昵称"
        v-model="name"
        maxlength="30"
        show-word-limit
        style="width: 50%"
      >
      </el-input>
      <div style="margin: 10px 0"></div>
      <el-input
        type="text"
        placeholder="您的邮箱（当有人回复时会通知您）"
        v-model="email"
        maxlength="40"
        show-word-limit
        style="width: 50%"
      >
      </el-input>
      <div style="margin: 10px 0"></div>
      <el-input
        type="textarea"
        placeholder="请输入内容"
        v-model="newComment"
        maxlength="999"
        show-word-limit
        @keyup.enter="addComment"
        :autosize="{ minRows: 3, maxRows: 6 }"
      >
      </el-input>
      <div style="margin: 20px 0"></div>

      <el-button type="primary" @click="addComment" :disabled="!newComment">
        提交
      </el-button>
    </div>

    <!-- <div class="comments-list">
      <h3>评论区</h3>
      <div v-for="(comment, index) in comments" :key="index" class="comment">
        <comment-card
          :comment="comment.content"
          :name="comment.author"
          avatar="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"
        />
      </div>
    </div> -->
    <comment-list :comment-list="comments"></comment-list>
  </el-card>
</template>

<script>
import CommentCard from './CommentCard.vue';
import CommentList from './CommentList.vue';
import { postComment } from '@/api/article';

export default {
  name: 'CommentSection',
  components: {
    CommentCard,
    CommentList,
  },
  props: {
    comments: {
      type: Array,
      // default: () => [],
    },
    articleId: {
      required: true,
    },
  },
  data() {
    return {
      name: '',
      newComment: '',
      email: '',
      loading: false,
      // comments: this.comments,
    };
  },
  methods: {
    mounted() {
      console.log(comments);
    },
    addComment() {
      //article_id, name, email, content
      // console.log(this.articleId);
      let data = {
        articleId: this.articleId,
        name: this.name ?? '',
        content: this.newComment ?? '',
        email: this.email ?? '',
      };
      if (!data.name.trim()) {
        this.$message({
          message: '昵称不能为空',
          type: 'warning',
        });
        return;
      }
      if (!data.content.trim()) {
        this.$message({
          message: '内容不能为空',
          type: 'warning',
        });
        return;
      }
      if (data.email.trim()) {
        let email_Regex = new RegExp('^.+@[A-Z0-9a-z]+\.[a-zA-Z]+$');
        if (!email_Regex.test(data.email)) {
          this.$message({
            message: '邮箱格式错误！',
            type: 'warning',
          });
          return;
        }
      }
      this.loading=true;
      postComment(data).then((res) => {
        this.loading=false;
        this.$message({
          message: '留言成功!',
          type: 'success',
        })
        // this.$router.go(0);
      }).catch((err) => {
        this.$message({
          showClose: true,
          message: '警告：留言时发生错误：' + err.message,
          type: 'error'
        });
      });;
      this.comments.unshift({
        id: 1,
        userPhoto:
          'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png',
        name: this.name,
        //   area: '北京',
        createdTime: new Date().toLocaleString().replaceAll('/', '-'),
        // response: null,
        // responseName: null,
        // responseTime: null,
        content: this.newComment,
      });
      this.$router.go(0);
      this.newComment = ''; // 清空输入框
      this.name = ''; // 清空输入框
      this.email = ''; // 清空输入框
      this.$emit('comment-added', this.comments); // Emit 事件通知父组件
    },
  },
};
</script>

<style scoped>
.comment-section {
  margin-top: 20px;
}

.comments-list {
  margin-top: 20px;
}

.comment {
  margin-bottom: 10px;
}
</style>
