<template>
  <div class="comment-card">
    <div class="comment-header">
      <!-- <img :src="avatar" alt="Avatar" class="avatar" /> -->
      <el-avatar :src="avatar" :size="50"></el-avatar>
      <span class="nick-name">{{ name }}</span>
    </div>
    <div class="comment-body">
      <p>{{ comment }}</p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CommentCard',
  props: {
    comment: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    avatar: {
      type: String,
      required: true,
    },
  },
};
</script>

<style scoped>
.comment-card {
  /* margin-bottom: 10px;  */
}

.comment-header {
  display: flex;
  align-items: center;
  margin-bottom: 10px; /* 评论头部与正文之间的间距 */
}

.avatar {
  width: 40px; /* 头像宽度 */
  height: 40px; /* 头像高度 */
  border-radius: 50%; /* 圆形头像 */
  margin-right: 10px; /* 头像与昵称之间的间距 */
}

.nick-name {
  font-weight: bold; /* 昵称加粗 */
}
</style>
