<template>
  <div v-loading="loading">
    <div style="margin-bottom: 20px;">
      <span style="margin-right: 15px;">文章标签</span>
      <el-tag
        v-for="tag in uniqueTags"
        :key="tag.id"
        :type="selectedTag !== tag.id ? 'info' : 'default'"
        @close="removeTag(tag.id)"
        style="margin-right: 8px; cursor: pointer;"
        @click="toggleTag(tag)"
        effect="dark"
      >
        {{ tag.name }}
      </el-tag>
    </div>
  </div>
</template>

<script>
export default {
  name: 'TagFilter',
  props: {
    // articles: {
    //   type: Array,
    //   required: true
    // }
    tags: {
      type: Array,
      required: true
    },
    loading: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      selectedTag: 'all',  // 单选，存储选中的标签ID
    };
  },
  computed: {
    uniqueTags() {
      // 获取所有独特的标签
      let tags = this.tags;
      // let tags = this.articles.flatMap(article => article.labels);
      tags.unshift({ id: 'all', name: '全部' });
      const uniqueTags = [...new Set(tags.map(tag => tag.id))].map(id => {
        return tags.find(tag => tag.id === id);
      });
      return uniqueTags;
    }
  },
  methods: {
    toggleTag(tag) {
      if (this.selectedTag === tag.id) {
        // 如果点击的标签已选中，则取消选择
        // this.selectedTags = null;
      } else {
        // 否则将其设置为选中
        this.selectedTag = tag.id;
      }
      this.filterArticles();
    },
    // removeTag(tagId) {
    //   if (this.selectedTags === tagId) {
    //     this.selectedTags = null;  // 取消选择
    //   }
    //   this.filterArticles();
    // },
    filterArticles() {
      this.$emit('filter', this.selectedTag !== 'all' ? [this.selectedTag] : this.uniqueTags.map(tag => tag.id));
    }
  }
}
</script>

<style scoped>
.el-tag {
  transition: background-color 0.2s ease, color 0.2s ease;
}
/* .el-tag:hover {
  background-color: rgba(65, 126, 255, 0.2); 
} */
</style>
