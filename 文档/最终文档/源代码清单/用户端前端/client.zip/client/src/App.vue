<template>
  <div id="app">
    <Loading v-if="loading"></Loading>
    <router-view/>
  </div>
</template>

<script>
import Loading from './components/Loading.vue';

export default {
  name: 'App',
  components: {
    Loading
  },
  data() {
    return {
      loading: false
    };
  },
  created() {
    // 监听路由变化
    // this.$router.beforeEach((to, from, next) => {
    //   this.loading = true; // 开始加载
    //   next();
    // });

    // this.$router.afterEach(() => {
    //   setTimeout(() => {this.loading = false}, 400);// 加载完成
    // });
  }
}
</script>

<style>
#app{
  height: 100%;
}
</style>
