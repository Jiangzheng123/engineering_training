<script>
  export default {
    name: "Aside",
    props: {
      isCollapse: Boolean,
      logoTextShow: Boolean
    }
  }
</script>

<template>
  <el-menu :default-openeds="['1', '3']"
           style="height: 100%; overflow-x: hidden"
           :collapse-transition="false"
           :collapse="isCollapse"
           :default-active="$route.path"
           router
  >
    <div style="height: 60px; line-height: 60px; text-align: center">
      <img src="../assets/logo.png" alt="" style="width: 20px; position: relative; top: 5px">
      <b style="margin-left: 5px" v-show="logoTextShow">管理端</b>
    </div>
    <el-menu-item index="/home">
      <i class="el-icon-s-home"></i>
      <span slot="title">主页</span>
    </el-menu-item>
    <el-menu-item index="/label">
      <i class="el-icon-collection-tag"></i>
      <span slot="title">标签管理</span>
    </el-menu-item>
    <el-menu-item index="/article">
      <i class="el-icon-document"></i>
      <span slot="title">文章管理</span>
    </el-menu-item>
    <el-menu-item index="/image">
      <i class="el-icon-picture"></i>
      <span slot="title">图片管理</span>
    </el-menu-item>
    <el-menu-item index="/comment">
      <i class="el-icon-s-comment"></i>
      <span slot="title">评论管理</span>
    </el-menu-item>
    <el-menu-item index="/webInfo">
      <i class="el-icon-info"></i>
      <span slot="title">网站信息管理</span>
    </el-menu-item>
  </el-menu>
</template>

<style scoped>

</style>