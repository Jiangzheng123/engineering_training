<template>
  <div style="font-size: 12px;  line-height: 60px; display: flex">
    <div style="flex: 1; font-size: 25px">
      <span :class="collapseBtnClass" style="cursor: pointer" @click="collapse"></span>
    </div>
    <el-dropdown style="width: 120px; cursor: pointer; margin: 10px">
      <el-avatar :src="imgUrl" shape="circle" style="margin-right: 5px"></el-avatar>
      <!-- 这里如果用户名太长会导致显示错误，使用可以隐藏的组件试一试吧 -->
      <span>{{ nickName }}</span><i class="el-icon-arrow-down" style="margin-left: 5px"></i>
      <el-dropdown-menu slot="dropdown" style="text-align: center">
        <el-dropdown-item @click.native="userInfo">个人信息</el-dropdown-item>
        <el-dropdown-item @click.native="logOut">退出</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
  </div>
</template>

<script>
  export default {
    name: "Header",
    props: {
      collapseBtnClass: String,
      collapse: Function,
      imgUrl: String,
      nickName: String,
      logOut: Function,
      userInfo: Function
    }
  }
</script>

<style scoped>

</style>