<script>
  export default {
    name: "LabelView",
    data () {
      return {
        labelName: "",
        pageNum: 1,
        pageSize: 10,
        tableData: [],
        total: 0,
        dialogVisible: false,
        dialog: {
          id: 0,
          name: '',
          description: ''
        },
        formLabelWidth: '120px'
      }
    },
    created() { // 页面一创建就执行的动作
      // 请求分页查询数据
      this.loadData()
    },
    methods: {
      loadData() {
        this.request.get('/label', {
          params: {
            pageNum: this.pageNum,
            pageSize: this.pageSize,
            labelName: this.labelName
          }
        }).then(res => {
          if(res.code === 200){
            this.tableData = res.data.records
            this.total = res.data.total
          }else{
            this.$message.error(res.message)
          }
        })
      },
      handleSizeChange(pageSize) {
        this.pageSize = pageSize
        this.loadData()
      },
      handleCurrentChange(pageNum) {
        this.pageNum = pageNum
        this.loadData()
      },
      indexMethod(index) {
        return index+1
      },
      handleEdit(row){
        this.dialog.id = row.id
        this.dialog.name = row.name
        this.dialog.description = row.description
        this.dialogVisible = true
      },
      handleDelete(row){
        this.request.delete('/label', {
          params: {
            id: row.id
          }
        }).then(res => {
          if(res.code === 200){
            this.$message.success(res.message)
            this.loadData()
          }else{
            this.$message.error(res.message)
          }
        })
      },
      saveLabel(){
        this.request.post('/label', this.dialog).then(res => {
          if(res.code === 200){
            this.$message.success(res.message)
            this.loadData()
          }else{
            this.$message.error(res.message)
          }
        })
        this.dialogVisible = false
      },
      insertLabel(){
        this.dialog = {}
        this.dialogVisible = true
      }
    }
  }
</script>

<template>
  <div>
    <div style="margin: 10px 0">
      <el-input style="width: 300px" placeholder="请输入标签名称" v-model="labelName"></el-input>
      <el-button style="margin-left: 5px" type="primary" icon="el-icon-search" @click="loadData">搜索</el-button>
      <el-button type="primary" icon="el-icon-plus" @click="insertLabel">新增</el-button>
    </div>

    <el-table :data="tableData" border stripe>
      <el-table-column type="index" :index="indexMethod" label="序号" width="50px"></el-table-column>
      <el-table-column prop="name" label="标签名"></el-table-column>
      <el-table-column prop="description" label="标签描述"></el-table-column>
      <el-table-column prop="createdTime" label="创建时间"></el-table-column>
      <el-table-column prop="operation" label="操作">
        <template slot-scope="scope">
          <el-button type="success" icon="el-icon-edit" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button type="danger" icon="el-icon-minus" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div style="padding: 10px 0">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pageNum"
          :page-sizes="[5, 10, 15, 20]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total">
      </el-pagination>
    </div>

    <el-dialog
        title="标签信息"
        :visible.sync="dialogVisible"
        width="30%">
      <el-form :model="dialog">
        <el-form-item label="标签名称" :label-width="formLabelWidth">
          <el-input v-model="dialog.name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="标签描述" :label-width="formLabelWidth">
          <el-input type='textarea' autosize v-model="dialog.description" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveLabel">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<style scoped>

</style>