<script>
  import axios from "axios";

  export default {
    name: "WebInfoView",
    data() {
      return {
        webInfo: {
          id: 0,
          name: '',
          description: '',
          articleContent: ''
        },
        formLabelWidth: '120px'
      }
    },
    methods: {
      imgAdd(pos, $file){
        let $vm = this.$refs.md
        // 第一步.将图片上传到服务器.
        const formData = new FormData();
        formData.append('file', $file);
        axios({
          url: `http://localhost:9090/admin/articleImg`,
          method: 'post',
          data: formData,
          headers: {
            'Content-Type': 'multipart/form-data',
            'token': localStorage.getItem('token')
          }
        }).then((res) => {
          // 第二步.将返回的url替换到文本原位置![...](./0) -> ![...](url)
          $vm.$img2Url(pos, res.data.data.url);
        })
      },
      loadData() {
        this.request.get("/webInfo").then(res => {
          if(res.code === 200){
            this.$message.success(res.message)
            this.webInfo.id = res.data.id
            this.webInfo.name = res.data.name
            this.webInfo.description = res.data.description
            this.webInfo.articleContent = res.data.articleContent
          }else{
            this.$message.error(res.message)
          }
        })
      },
      saveWebInfo() {
        this.request.post('/webInfo', this.webInfo).then(res => {
          if(res.code === 200){
            this.$message.success(res.message)
          }else{
            this.$message.error(res.message)
          }
        })
      }
    },
    created() {
      this.loadData()
    }
  }
</script>

<template>
  <div>
    <el-form :model="webInfo" size="large" :label-width="formLabelWidth">
      <el-form-item label="网站名称">
        <el-input v-model="webInfo.name" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="网站描述">
        <el-input type='textarea' autosize v-model="webInfo.description" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="网站介绍文章">
        <mavon-editor ref="md" v-model="webInfo.articleContent" :ishljs="true" @imgAdd="imgAdd"/>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="saveWebInfo" style="position: absolute; right: 0%">保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<style scoped>

</style>