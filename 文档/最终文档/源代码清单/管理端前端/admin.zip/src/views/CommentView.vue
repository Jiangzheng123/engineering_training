<script>
  export default {
    name: "CommentView",
    data () {
      return {
        pageNum: 1,
        pageSize: 10,
        tableData: [],
        total: 0,
        srcList: [],
        dialogVisible: false,
        formLabelWidth: '120px',
        dialog: {
          replyId: 0,
          articleId: 0,
          name: '',
          email: '',
          content: ''
        }
      }
    },
    created() { // 页面一创建就执行的动作
      // 请求分页查询数据
      this.loadData()
    },
    methods: {
      loadData() {
        this.request.get('/comment', {
          params: {
            pageNum: this.pageNum,
            pageSize: this.pageSize
          }
        }).then(res => {
          if(res.code === 200){
            this.tableData = res.data.records
            this.total = res.data.total
          }else{
            this.$message.error(res.message)
          }
        })
      },
      handleSizeChange(pageSize) {
        this.pageSize = pageSize
        this.loadData()
      },
      handleCurrentChange(pageNum) {
        this.pageNum = pageNum
        this.loadData()
      },
      indexMethod(index) {
        return index+1
      },
      handleDelete(row){
        this.request.delete('/comment', {
          params: {
            id: row.id
          }
        }).then(res => {
          if(res.code === 200){
            this.$message.success(res.message)
            this.loadData()
          }else{
            this.$message.error(res.message)
          }
        })
      },
      handleReply(row){
        this.dialog = {}
        this.dialog.replyId = row.id
        this.dialog.articleId = row.articleId
        this.dialogVisible = true
      },
      saveComment(){
        this.request.post('/comment', this.dialog).then(res => {
          if(res.code === 200){
            this.$message.success(res.message)
            this.loadData()
          }else{
            this.$message.error(res.message)
          }
        })
        this.dialogVisible = false
      }
    }
  }
</script>

<template>
  <div>
    <el-table :data="tableData" border stripe>
      <el-table-column type="index" :index="indexMethod" label="序号" width="50px"></el-table-column>
      <el-table-column prop="name" label="评论人昵称"></el-table-column>
      <el-table-column prop="email" label="评论人邮箱"></el-table-column>
      <el-table-column prop="content" label="评论内容"></el-table-column>
      <el-table-column prop="createdTime" label="评论时间"></el-table-column>
      <el-table-column prop="operation" label="操作">
        <template slot-scope="scope">
          <el-button type="success" icon="el-icon-chat-dot-square" @click="handleReply(scope.row)">回复</el-button>
          <el-button type="danger" icon="el-icon-minus" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div style="padding: 10px 0">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pageNum"
          :page-sizes="[5, 10, 15, 20]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total">
      </el-pagination>
    </div>

    <el-dialog
        title="回复信息"
        :visible.sync="dialogVisible"
        width="30%">
      <el-form :model="dialog" size="small" :label-width="formLabelWidth">
        <el-form-item label="回复人昵称">
          <el-input v-model="dialog.name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="回复人邮箱">
          <el-input v-model="dialog.email" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="回复内容">
          <el-input type='textarea' autosize v-model="dialog.content" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>

      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveComment">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<style scoped>

</style>