<script>
  import * as echarts from 'echarts'

  export default {
    name: "HomeView",
    data() {
      return {
        articleNum: 0,
        imgNum: 0,
        commentNum: 0,
        likeNum: 0
      }
    },
    methods: {
      loadData(){
        this.request.get('/home/overview').then(res => {
          if(res.code === 200){
            this.articleNum = res.data.articleNum
            this.imgNum = res.data.imgNum
            this.commentNum = res.data.commentNum
            this.likeNum = res.data.likeNum
          }
        })
      },
      loadEchart(){
        let articleChart = echarts.init(document.getElementById('articleChart'));
        let articleOption = {
          title: {
            text: '各季度文章创作数示意图',
            subtext: '统计图',
            left: 'center'
          },
          xAxis: {
            type: 'category',
            data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
          },
          yAxis: {
            type: 'value'
          },
          series: [
            {
              data: [150, 230, 224, 218, 135, 147, 260],
              type: 'bar'
            }
          ]
        };
        // 在这里向后端请求数据，然后更新option里相关变量的值即可
        this.request.get("/home/articleChart").then(res => {
          if(res.code === 200){
            articleOption.xAxis.data = res.data.xdata
            articleOption.series[0].data = res.data.ydata
            articleChart.setOption(articleOption); // 要在里面设，因为是异步请求
          }
        })

        let commentChart = echarts.init(document.getElementById('commentChart'));
        let commentOption = {
          title: {
            text: '各季度评论数示意图',
            subtext: '趋势图',
            left: 'center'
          },
          xAxis: {
            type: 'category',
            data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
          },
          yAxis: {
            type: 'value'
          },
          series: [
            {
              data: [150, 230, 224, 218, 135, 147, 260],
              type: 'line',
              smooth: true
            }
          ]
        };
        // 在这里向后端请求数据，然后更新option里相关变量的值即可
        this.request.get("/home/commentChart").then(res => {
          if(res.code === 200){
            commentOption.xAxis.data = res.data.xdata
            commentOption.series[0].data = res.data.ydata
            commentChart.setOption(commentOption); // 要在里面设，因为是异步请求
          }
        })
      }
    },
    mounted() {
      this.loadEchart()
    },
    created() {
      this.loadData()
    }
  }
</script>

<template>
  <div>
    <el-row :gutter="10" style="margin-bottom: 40px">
      <el-col :span="6">
        <el-card>
          <div style="color: #409EFF">
            文章数
          </div>
          <div style="padding: 10px 0; text-align: right; font-weight: bold">
            {{ articleNum }}
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card>
          <div style="color: #67C23A">
            图片数
          </div>
          <div style="padding: 10px 0; text-align: right; font-weight: bold">
            {{ imgNum }}
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card>
          <div style="color: #E6A23C">
            评论数
          </div>
          <div style="padding: 10px 0; text-align: right; font-weight: bold">
            {{ commentNum }}
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card>
          <div style="color: #909399">
            点赞数
          </div>
          <div style="padding: 10px 0; text-align: right; font-weight: bold">
            {{ likeNum }}
          </div>
        </el-card>
      </el-col>
    </el-row>
    <el-row :gutter="10" type="flex"> <!-- 水平并列展示 -->
      <el-col :sapn="12">
        <div id="articleChart" style="width: 600px; height: 450px"></div>
      </el-col>
      <el-col :span="12">
        <div id="commentChart" style="width: 600px; height: 450px"></div>
      </el-col>
    </el-row>
  </div>
</template>

<style scoped>

</style>