<template>
  <div class="manage" style="height: 100%">
    <el-container style="height: 100%">
      <el-aside :width="asideWidth + 'px'" style="background-color: rgb(238, 241, 246); height: 100%">
        <Aside :is-collapse="isCollapse" :logo-text-show="logoTextShow"></Aside>
      </el-aside>

      <el-container>
        <el-header style="border-bottom: 1px solid #cccccc">
          <Header :collapse-btn-class="collapseBtnClass" :collapse="collapse"
                  :img-url="imgUrl" :log-out="logOut" :nick-name="nickName"
                  :user-info="userInfo">
          </Header>
        </el-header>

        <el-main>
          <!-- 表示当前页面的子路由会在此展示 -->
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>

    <el-dialog
        title="用户信息"
        :visible.sync="dialogVisible"
        width="50%">
      <el-form :model="dialog" :rules="rules" ref="form" :label-width="formLabelWidth">
        <el-form-item label="用户账号">
          <el-input v-model="dialog.account" autocomplete="off" readonly></el-input>
        </el-form-item>
        <el-form-item label="用户昵称">
          <el-input v-model="dialog.nickName" autocomplete="off" @input="onInput"></el-input>
        </el-form-item>
        <el-form-item label="用户头像">
          <el-upload
              action="http://localhost:9090/admin/userImg"
              :headers="headers"
              :show-file-list="false"
              class="avatar-uploader"
              :on-success="onSuccess"
              :before-upload="beforeAvatarUpload"
          >
            <!-- 使用el-avatar可保证图片url一改变就重新加载 -->
            <el-avatar v-if="dialog.imgUrl" :src="dialog.imgUrl"/>
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
        <el-form-item label="新密码" prop="newPassword">
          <el-input type="password" v-model="dialog.newPassword" @input="onInput"></el-input>
        </el-form-item>
        <el-form-item label="确认密码" prop="confirmPassword">
          <el-input type="password" v-model="dialog.confirmPassword" @input="onInput"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveInfo">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  import Aside from "@/components/Aside.vue";
  import Header from "@/components/Header.vue";

  export default {
    name: 'ManageView',
    data() {
      return {
        isCollapse: false,
        asideWidth: 200,
        collapseBtnClass: "el-icon-s-fold",
        logoTextShow: true,
        imgUrl: '',
        nickName: '',
        account: '',
        dialogVisible: false,
        dialog: {
          account: '',
          nickName: '',
          imgUrl: '',
          newPassword: '',
          confirmPassword: ''
        },
        formLabelWidth: '120px',
        headers: {
          "token": localStorage.getItem("token")
        },
        rules:{
          newPassword:[
            {required:false,message:"请输入新密码",trigger:"blur"},
            {min: 5, max: 14, message: '长度在 5 到 14 个字符', trigger: 'blur'}
          ],
          confirmPassword:[
            {required:false,message:"请再次输入新密码",trigger:"blur"},
            {validator: (rule, value, callback) => {
                if (value !== this.dialog.newPassword) {
                  callback(new Error('两次输入密码不一致'));
                } else {
                  callback();
                }
              }, trigger: 'blur' }]
        }
      }
    },
    methods: {
      collapse() {  // 侧边栏收缩与展开
        this.isCollapse = !this.isCollapse;
        this.logoTextShow = !this.logoTextShow;
        if(this.isCollapse){
          this.asideWidth = 65;
          this.collapseBtnClass = "el-icon-s-unfold";
        }else{
          this.asideWidth = 200;
          this.collapseBtnClass = "el-icon-s-fold";
        }
      },
      logOut() {  // 登出
        localStorage.removeItem("token")
        this.$message.success("退出成功")
        this.$router.push("/login")
      },
      getUserInfo() { // 获取用户信息
        this.request.get('/userInfo').then(res => {
          if(res.code !== 200){
            this.$message.error(res.message)
          }else{
            this.imgUrl = res.data.imgUrl
            this.nickName = res.data.nickName
            this.account = res.data.account

            this.dialog = {}  // 重置是必要的，因为要将新密码和确认密码置空
            this.dialog.imgUrl = res.data.imgUrl
            this.dialog.nickName = res.data.nickName
            this.dialog.account = res.data.account
          }
        })
      },
      userInfo() {
        this.dialog = {}  // 重置是必要的，因为要将新密码和确认密码置空
        this.dialog.imgUrl = this.imgUrl
        this.dialog.nickName = this.nickName
        this.dialog.account = this.account
        this.dialogVisible = true
      },
      saveInfo() {
        this.$refs['form'].validate(valid => {
          if (valid) {
            // 表单验证通过，可以提交数据
            this.request.post('/userInfo', {
              nickname: this.dialog.nickName,
              password: this.dialog.newPassword
            }).then(res => {
              if(res.code !== 200){
                this.$message.error(res.message)
              }else{
                this.$message.success(res.message)
                this.getUserInfo()
                this.dialogVisible = false
              }
            })
          } else {
            // 表单验证不通过
            console.log('error submit!!');
          }
        });
      },
      beforeAvatarUpload(file) {
        let formatArr = ['image/png', 'image/jpg', 'image/jpeg']
        const isImg = (formatArr.indexOf(file.type.toLowerCase()) !== -1);
        const isLT1M = file.size / 1024 / 1024 <= 1;

        if (!isImg) {
          this.$message.error('只能上传图片!');
        }
        if (!isLT1M) {
          this.$message.error('上传头像图片大小不能超过 1MB!');
        }
        return isImg && isLT1M;
      },
      onSuccess(response, file, filelist) {
        this.dialog.imgUrl = response.data.url
        this.imgUrl = response.data.url // 对话框外的用户头像也一起更改
        this.$message.success(response.message)
      },
      onInput(){
        this.$forceUpdate()
      }
    },
    created() {
      this.getUserInfo()
    },
    components: {
      Aside,
      Header
    }
  }
</script>
