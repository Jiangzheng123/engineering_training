<script>
  export default {
    name: "ImageView",
    data () {
      return {
        pageNum: 1,
        pageSize: 10,
        tableData: [],
        total: 0,
        srcList: []
      }
    },
    created() { // 页面一创建就执行的动作
      // 请求分页查询数据
      this.loadData()
    },
    methods: {
      loadData() {
        this.request.get('/img', {
          params: {
            pageNum: this.pageNum,
            pageSize: this.pageSize
          }
        }).then(res => {
          if(res.code === 200){
            this.tableData = res.data.records
            this.total = res.data.total
          }else{
            this.$message.error(res.message)
          }
        })
      },
      handleSizeChange(pageSize) {
        this.pageSize = pageSize
        this.loadData()
      },
      handleCurrentChange(pageNum) {
        this.pageNum = pageNum
        this.loadData()
      },
      indexMethod(index) {
        return index+1
      },
      handleDelete(row){
        this.request.delete('/img', {
          params: {
            id: row.id
          }
        }).then(res => {
          if(res.code === 200){
            this.$message.success(res.message)
            this.loadData()
          }else{
            this.$message.error(res.message)
          }
        })
      },
      preview(url) {
        this.srcList = []
        this.srcList.push(url)
      }
    }
  }
</script>

<template>
  <div>
    <el-table :data="tableData" border stripe>
      <el-table-column type="index" :index="indexMethod" label="序号" width="50px"></el-table-column>
      <el-table-column prop="picture" label="图片" align="center">
        <template slot-scope="scope">
          <el-image :src="scope.row.url"
                    :preview-src-list="srcList"
                    style="width: 70%; height: 70%"
                    @click="preview(scope.row.url)"></el-image>
        </template>
      </el-table-column>
      <el-table-column prop="type" label="类型">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.type === 0">用户头像</el-tag>
          <el-tag type="success" v-if="scope.row.type === 1">文章配图</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="createdTime" label="创建时间"></el-table-column>
      <el-table-column prop="operation" label="操作">
        <template slot-scope="scope">
          <el-button type="danger" icon="el-icon-minus" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div style="padding: 10px 0">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pageNum"
          :page-sizes="[5, 10, 15, 20]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total">
      </el-pagination>
    </div>
  </div>
</template>

<style scoped>

</style>