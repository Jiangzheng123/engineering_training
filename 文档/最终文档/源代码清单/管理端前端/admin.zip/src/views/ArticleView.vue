<script>
  import axios from "axios";

  export default {
    name: "ArticleView",
    data () {
      return {
        articleName: "",
        pageNum: 1,
        pageSize: 10,
        tableData: [],
        total: 0,
        dialogVisible: false,
        dialog: {
          id: 0,
          title: '',
          introduction: '',
          content: ''
        },
        formLabelWidth: '120px'
      }
    },
    created() { // 页面一创建就执行的动作
      // 请求分页查询数据
      this.loadData()
    },
    methods: {
      loadData() {
        this.request.get('/article', {
          params: {
            pageNum: this.pageNum,
            pageSize: this.pageSize,
            articleName: this.articleName
          }
        }).then(res => {
          if(res.code === 200){
            this.tableData = res.data.records
            this.total = res.data.total
          }else{
            this.$message.error(res.message)
          }
        })
      },
      handleSizeChange(pageSize) {
        this.pageSize = pageSize
        this.loadData()
      },
      handleCurrentChange(pageNum) {
        this.pageNum = pageNum
        this.loadData()
      },
      indexMethod(index) {
        return index+1
      },
      handleEdit(row){
        this.dialog.id = row.id
        this.dialog.title = row.title
        this.dialog.introduction = row.introduction
        this.dialog.content = row.content
        this.dialogVisible = true
      },
      handleDelete(row){
        this.request.delete('/article', {
          params: {
            id: row.id
          }
        }).then(res => {
          if(res.code === 200){
            this.$message.success(res.message)
            this.loadData()
          }else{
            this.$message.error(res.message)
          }
        })
      },
      saveArticle(){
        this.request.post('/article', this.dialog).then(res => {
          if(res.code === 200){
            this.$message.success(res.message)
            this.loadData()
          }else{
            this.$message.error(res.message)
          }
        })
        this.dialogVisible = false
      },
      insertArticle(){
        this.dialog = {}
        this.dialogVisible = true
      },
      imgAdd(pos, $file){
        let $vm = this.$refs.md
        // 第一步.将图片上传到服务器.
        const formData = new FormData();
        formData.append('file', $file);
        axios({
          url: `http://localhost:9090/admin/articleImg`,
          method: 'post',
          data: formData,
          headers: {
            'Content-Type': 'multipart/form-data',
            'token': localStorage.getItem('token')
          }
        }).then((res) => {
          // 第二步.将返回的url替换到文本原位置![...](./0) -> ![...](url)
          $vm.$img2Url(pos, res.data.data.url);
        })
      }
    }
  }
</script>

<template>
  <div>
    <!-- 这里可以新增按标签搜索的功能 -->
    <div style="margin: 10px 0">
      <el-input style="width: 300px" placeholder="请输入文章名称" v-model="articleName"></el-input>
      <el-button style="margin-left: 5px" type="primary" icon="el-icon-search" @click="loadData">搜索</el-button>
      <el-button type="primary" icon="el-icon-plus" @click="insertArticle">新增</el-button>
    </div>

    <!-- 别忘了在这里添加标签列 -->
    <el-table :data="tableData" border stripe>
      <el-table-column type="index" :index="indexMethod" label="序号" width="50px"></el-table-column>
      <el-table-column prop="title" label="文章标题"></el-table-column>
      <el-table-column prop="introduction" label="文章简介"></el-table-column>
      <el-table-column prop="version" label="文章版本"></el-table-column>
      <el-table-column prop="createdTime" label="创建时间"></el-table-column>
      <el-table-column prop="operation" label="操作">
        <template slot-scope="scope">
          <el-button type="success" icon="el-icon-edit" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button type="danger" icon="el-icon-minus" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div style="padding: 10px 0">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pageNum"
          :page-sizes="[5, 10, 15, 20]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total">
      </el-pagination>
    </div>

    <el-dialog
        title="文章信息"
        :visible.sync="dialogVisible"
        width="80%">
      <el-form :model="dialog" size="small" :label-width="formLabelWidth">
        <el-form-item label="文章标题">
          <el-input v-model="dialog.title" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="文章简介">
          <el-input type='textarea' autosize v-model="dialog.introduction" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="文章内容">
          <mavon-editor ref="md" v-model="dialog.content" :ishljs="true" @imgAdd="imgAdd"/>
        </el-form-item>
      </el-form>

      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveArticle">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<style scoped>

</style>