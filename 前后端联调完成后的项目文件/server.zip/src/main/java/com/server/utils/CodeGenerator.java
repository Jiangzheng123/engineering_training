package com.server.utils;

import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.OutputFile;
import com.baomidou.mybatisplus.generator.engine.FreemarkerTemplateEngine;

import java.nio.file.Paths;
import java.util.Collections;

/**
 * mp代码生成器
 */
public class CodeGenerator {
    public static void main(String[] args) {
        generate();
    }

    private static void generate() {
        FastAutoGenerator.create("jdbc:mysql://localhost:3306/blog", "root", "123456")
                .globalConfig(builder -> builder
                        .author("JiangZheng")
                        .enableSwagger()    // 开启Swagger模式
                        // .fileOverride()     // 覆盖已生成的文件
                        .outputDir(Paths.get(System.getProperty("user.dir")) + "\\server\\src\\main\\java") // 指定输出目录
                        .commentDate("yyyy-MM-dd")
                )
                .packageConfig(builder -> builder
                        .parent("com.server")   // 设置父包名
                        .moduleName("") // 设置父包模块名
                        // 设置mapperXml生成目录
                        .pathInfo(Collections.singletonMap(OutputFile.mapperXml, Paths.get(System.getProperty("user.dir")) + "\\server\\src\\main\\resources\\mapper"))
                )
                .strategyConfig(builder -> builder
                        .addInclude("user", "article", "label", "article_label", "image", "web_info", "milestones", "log", "comment") //设置需要生成的表名
                        .addTablePrefix("t_")   // 设置过滤表前缀
                        .entityBuilder()
                        .enableLombok() // 设置实体类采用Lombok
                        .controllerBuilder()
                        .enableRestStyle()  // 设置为Controller类生成RestController注解
                )
                .templateEngine(new FreemarkerTemplateEngine())
                .execute();
    }
}
