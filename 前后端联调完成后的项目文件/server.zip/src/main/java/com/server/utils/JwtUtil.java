package com.server.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Map;

public class JwtUtil {
    // 指定签名的时候使用的签名算法
    private static final SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
    // 指定密钥的编码方式
    private static final Charset charset = StandardCharsets.UTF_8;

    /**
     * 生成jwt
     */
    public static String createJWT(String secretKey, long ttlMillis, Map<String, Object> claims) {
        // 生成JWT的时间
        Date exp = new Date(System.currentTimeMillis() + ttlMillis);

        // 设置jwt的body，返回类型是String
        return Jwts.builder()
                .setClaims(claims)
                .signWith(signatureAlgorithm, secretKey.getBytes(charset))
                .setExpiration(exp).compact();
    }

    /**
     * Token解密
     */
    public static Claims parseJWT(String secretKey, String token) {
        return Jwts.parser()
                .setSigningKey(secretKey.getBytes(charset))
                .parseClaimsJws(token)
                .getBody();
    }
}