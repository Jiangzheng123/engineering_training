package com.server.exception;

import lombok.Getter;

@Getter
public class MyException extends RuntimeException {
    private int code;
    private String message;

    public MyException(int code, String message) {
        this.code = code;
        this.message = message;
    }
}
