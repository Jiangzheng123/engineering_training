package com.server.interceptor;

import com.server.common.BaseContext;
import com.server.common.Constants;
import com.server.exception.MyException;
import com.server.properties.JwtProperties;
import com.server.utils.JwtUtil;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

@Component
public class JwtTokenInterceptor implements HandlerInterceptor {
    @Autowired
    private JwtProperties jwtProperties;

    /**
     * 目标资源方法运行前运行
     * @param request
     * @param response
     * @param handler
     * @return 返回true放行，返回false不放行
     * @throws Exception
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //当前拦截到的不是动态方法，直接放行
        if (!(handler instanceof HandlerMethod)) {
            return true;
        }

        //1、从请求头中获取令牌
        String token = request.getHeader(jwtProperties.getTokenName());

        //2、校验令牌
        try {
            Claims claims = JwtUtil.parseJWT(jwtProperties.getSecretKey(), token);
            Date expirationTime = claims.getExpiration();  //获取令牌中的过期时间
            // 判断过期时间是否大于当前时间
            if (expirationTime.before(new Date())) {
                throw new Exception("JWT令牌已过期！");
            }
            BaseContext.setCurrentId(claims.get("id", Integer.class)); //设置该线程当前处理的用户id
            //3、通过，放行
            return true;
        } catch (Exception e) {
            //4、不通过，通过自定义异常进行处理
            throw new MyException(Constants.CODE_401, "请先登录");
        }
    }
}
