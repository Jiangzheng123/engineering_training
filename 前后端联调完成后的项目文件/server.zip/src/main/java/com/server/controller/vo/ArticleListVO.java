package com.server.controller.vo;

import com.server.entity.Article;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ArticleListVO {
    private int total;
    private List<Article> records;
}
