package com.server.controller.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OverviewVO {
    private long articleNum;
    private long imgNum;
    private long commentNum;
    private long likeNum;
}
