package com.server.controller.vo;

import com.server.entity.Comment;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CommentListVO {
    private int total;
    private List<Comment> records;
}
