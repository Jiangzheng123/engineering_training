package com.server.controller;


import com.server.common.BaseContext;
import com.server.common.Result;
import com.server.controller.dto.LoginDTO;
import com.server.controller.dto.UserInfoDTO;
import com.server.controller.vo.LoginVO;
import com.server.controller.vo.UserInfoVO;
import com.server.entity.Image;
import com.server.entity.User;
import com.server.service.IImageService;
import com.server.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 用户表 前端控制器
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@RestController
public class UserController {
    @Autowired
    IUserService userService;
    @Autowired
    IImageService imageService;

    /**
     * 用户登录接口
     * @param loginDTO
     * @return
     */
    @PostMapping("admin/login")
    public Result login(@RequestBody LoginDTO loginDTO) {
        String token = userService.login(loginDTO.getAccount(), loginDTO.getPassword());
        LoginVO loginVO = new LoginVO(token);
        return Result.success(loginVO);
    }

    @GetMapping("admin/userInfo")
    public Result getUserInfo() {
        int userId = BaseContext.getCurrentId();
        User user = userService.getById(userId);
        Image image = imageService.getById(user.getImageId());
        UserInfoVO userInfoVO = new UserInfoVO();
        userInfoVO.setImgUrl(image.getUrl());
        userInfoVO.setAccount(user.getAccount());
        userInfoVO.setNickName(user.getNickname());
        return Result.success(userInfoVO);
    }

    @PostMapping("admin/userInfo")
    public Result updateUserInfo(@RequestBody UserInfoDTO userInfoDTO) {
        int userId = BaseContext.getCurrentId();
        User user = userService.getById(userId);
        user.setNickname(userInfoDTO.getNickname());
        if(userInfoDTO.getPassword() != null) {
            user.setPassword(userInfoDTO.getPassword());
        }
        userService.updateById(user);
        return Result.success();
    }
}
