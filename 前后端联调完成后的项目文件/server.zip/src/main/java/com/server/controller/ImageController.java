package com.server.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.server.common.BaseContext;
import com.server.common.Result;
import com.server.controller.vo.ImageListVO;
import com.server.controller.vo.UploadImgVO;
import com.server.entity.Image;
import com.server.entity.User;
import com.server.service.IImageService;
import com.server.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.util.UUID;

/**
 * <p>
 * 图像表 前端控制器
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@RestController
public class ImageController {
    @Autowired
    IImageService imageService;
    @Autowired
    IUserService userService;

    private static final String basePath = System.getProperty("user.dir") + "\\img\\";
    private static final String baseUrl = "http://localhost:9090/img/";

    @PostMapping("/admin/userImg")
    public Result uploadUserImg(MultipartFile file) throws Exception {
        String url = storeImg(file, 0);
        updateUserImg(url);
        UploadImgVO uploadImgVO = new UploadImgVO(url);
        return Result.success(uploadImgVO);
    }

    @PostMapping("/admin/articleImg")
    public Result uploadArticleImg(MultipartFile file) throws Exception {
        String url = storeImg(file, 1);
        UploadImgVO uploadImgVO = new UploadImgVO(url);
        return Result.success(uploadImgVO);
    }

    @GetMapping("/admin/img")
    public Result getImg(@RequestParam int pageNum, @RequestParam int pageSize) {
        IPage<Image> page = imageService.searchWithPage(pageNum, pageSize);
        ImageListVO imageListVO = new ImageListVO((int)page.getTotal(), page.getRecords());
        return Result.success(imageListVO);
    }

    @DeleteMapping("/admin/img")
    public Result deleteImg(@RequestParam int id) {
        Image image = imageService.getById(id);
        removeImgByUrl(image.getUrl());
        imageService.removeById(id);
        return Result.success();
    }

    @GetMapping("/img/{name}")
    public void getImg(@PathVariable String name, HttpServletResponse response) throws Exception {
        System.out.println();
        // 通过输入流读取文件内容
        FileInputStream fileInputStream = new FileInputStream(new File(basePath+name));
        // 通过输出流将文件传至浏览器
        ServletOutputStream outputStream = response.getOutputStream();
        response.setContentType("image/jpeg");
        int len = 0;
        byte[] bytes = new byte[1024];
        while((len = fileInputStream.read(bytes))!= -1){
            outputStream.write(bytes,0,len);
            outputStream.flush();
        }
        //关闭资源
        outputStream.close();
        fileInputStream.close();
    }

    /**
     * 将上传的图片存储到本地
     * @param file
     * @param type 0代表用户头像，1代表文章配图
     * @return 返回本地存储的图片路径
     * @throws Exception
     */
    private String storeImg(MultipartFile file, int type) throws Exception {
        // 获取原始文件名，从而获取文件后缀
        String originalFileName = file.getOriginalFilename();
        String suffix = originalFileName.substring(originalFileName.lastIndexOf("."));

        // 使用UUID重新生成文件名，防止文件名称重复造成文件覆盖
        String fileName = UUID.randomUUID().toString() + suffix;

        // 创建一个目录对象
        File dir = new File(basePath);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        // 将临时文件转存到指定的位置
        file.transferTo(new File(basePath + fileName));


        // 将图片信息存储到数据库中
        Image image = new Image();
        image.setType(type);
        image.setUrl(baseUrl + fileName);
        imageService.save(image);

        return baseUrl + fileName;
    }

    /**
     * 在本地删除图片
     * @param url 要删除图片对应的url地址
     */
    private void removeImgByUrl(String url) {
        String fileName = url.substring(url.lastIndexOf("/")+1);
        File file = new File(basePath + fileName);
        file.delete();
    }

    /**
     * 更新用户关联的头像
     * @param url 要关联头像的url
     */
    private void updateUserImg(String url){
        // 获取当前用户信息
        int userId = BaseContext.getCurrentId();
        User user = userService.getById(userId);
        // 删除原用户头像（若用户有头像的话）
        if(user.getImageId() != null){
            String oldUrl = imageService.getById(user.getImageId()).getUrl();
            removeImgByUrl(oldUrl); // 本地删除
            imageService.removeById(user.getImageId()); // 数据库中删除
        }
        // 更新当前用户关联的图像id
        QueryWrapper<Image> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("url", url);
        Image image = imageService.getOne(queryWrapper);
        user.setImageId(image.getId());
        userService.updateById(user);
    }
}
