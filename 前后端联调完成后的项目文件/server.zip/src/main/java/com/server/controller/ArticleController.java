package com.server.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.server.common.Result;
import com.server.controller.dto.LikeDTO;
import com.server.controller.vo.ArticleListVO;
import com.server.controller.vo.ArticleVO;
import com.server.entity.Article;
import com.server.service.IArticleService;
import com.server.service.ICommentService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 文章表 前端控制器
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@RestController
public class ArticleController {

    @Autowired
    IArticleService articleService;
    @Autowired
    ICommentService commentService;

    @GetMapping("/admin/article")
    public Result adminArticle(@RequestParam int pageNum, @RequestParam int pageSize, @RequestParam String articleName) {
        IPage<Article> page = articleService.searchWithPage(pageNum, pageSize, articleName);
        ArticleListVO articleListVO = new ArticleListVO((int)page.getTotal(), page.getRecords());
        return Result.success(articleListVO);
    }

    @DeleteMapping("/admin/article")
    public Result deleteArticle(@RequestParam int id) {
        articleService.removeById(id);
        return Result.success();
    }

    @PostMapping("/admin/article")
    public Result saveArticle(@RequestBody Article article) {
        articleService.saveOrUpdate(article);
        return Result.success();
    }

    @GetMapping("/client/pageArticle")
    public Result userArticle(@RequestParam int page, @RequestParam int size, @RequestParam String title, @RequestParam String tagId) {
        IPage<Article> ipage = articleService.searchWithPage(page+1, size, title);
        ArticleListVO articleListVO = new ArticleListVO((int)ipage.getTotal(), ipage.getRecords());
        return Result.success(ipage);   // 前端要求，那就直接传吧
    }

    @GetMapping("/client/article")
    public Result getArticle(@RequestParam int id) {
        Article article = articleService.getById(id);
        // 需要补充评论列表
        ArticleVO articleVO = new ArticleVO();
        BeanUtils.copyProperties(article, articleVO);
        articleVO.setComments(commentService.getArticleComment(article.getId()));
        return Result.success(articleVO);
    }

    @PostMapping("/client/like")
    public Result like(@RequestBody LikeDTO likeDTO) {
        int articleId = likeDTO.getId();
        int incrementNum = likeDTO.isLiked() ? 1 : -1;
        articleService.updateLikeNum(articleId, incrementNum);
        Article article = articleService.getById(articleId);
        return Result.success(article.getLikeNum());
    }
}
