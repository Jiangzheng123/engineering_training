package com.server.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.Quarter;
import com.server.common.Result;
import com.server.controller.vo.ArticleChartVO;
import com.server.controller.vo.CommentChartVO;
import com.server.controller.vo.OverviewVO;
import com.server.entity.Article;
import com.server.entity.Comment;
import com.server.service.IArticleService;
import com.server.service.ICommentService;
import com.server.service.IImageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

@RestController
public class HomeController {
    @Autowired
    ICommentService commentService;
    @Autowired
    IArticleService articleService;
    @Autowired
    IImageService imageService;

    @GetMapping("/admin/home/commentChart")
    public Result getCommentChart() {
        List<Comment> commentList = commentService.list();
        int q1 = 0;
        int q2 = 0;
        int q3 = 0;
        int q4 = 0;
        for(Comment comment : commentList) {
            LocalDateTime createdTime = comment.getCreatedTime();
            Date date = Date.from(createdTime.atZone(ZoneId.systemDefault()).toInstant());
            Quarter quarter = DateUtil.quarterEnum(date);
            switch (quarter) {
                case Q1: q1++; break;
                case Q2: q2++; break;
                case Q3: q3++; break;
                case Q4: q4++; break;
                default: break;
            }
        }
        CommentChartVO commentChartVO = new CommentChartVO(
                CollUtil.newArrayList("第一季度", "第二季度", "第三季度", "第四季度"),
                CollUtil.newArrayList(q1, q2, q3, q4));
        return Result.success(commentChartVO);
    }

    @GetMapping("/admin/home/articleChart")
    public Result getArticleChart() {
        List<Article> articleList = articleService.list();
        int q1 = 0;
        int q2 = 0;
        int q3 = 0;
        int q4 = 0;
        for (Article article : articleList) {
            LocalDateTime createdTime = article.getCreatedTime();
            Date date = Date.from(createdTime.atZone(ZoneId.systemDefault()).toInstant());
            Quarter quarter = DateUtil.quarterEnum(date);
            switch (quarter) {
                case Q1: q1++; break;
                case Q2: q2++; break;
                case Q3: q3++; break;
                case Q4: q4++; break;
                default: break;
            }
        }
        ArticleChartVO articleChartVO = new ArticleChartVO(
                CollUtil.newArrayList("第一季度", "第二季度", "第三季度", "第四季度"),
                CollUtil.newArrayList(q1, q2, q3, q4));
        return Result.success(articleChartVO);
    }

    @GetMapping("/admin/home/overview")
    public Result getOverview() {
        long articleNum = articleService.count();
        long commentNum = commentService.count();
        long imageNum = imageService.count();
        long likeNum = articleService.getSumOfColumn("like_num");
        OverviewVO overviewVO = new OverviewVO(articleNum, imageNum, commentNum, likeNum);
        return Result.success(overviewVO);
    }
}
