package com.server.controller;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.Quarter;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.server.common.Result;
import com.server.controller.dto.CommentDTO;
import com.server.controller.vo.CommentChartVO;
import com.server.controller.vo.CommentListVO;
import com.server.entity.Comment;
import com.server.service.ICommentService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 评论表 前端控制器
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@RestController
public class CommentController {
    @Autowired
    ICommentService commentService;

    @PostMapping("/client/comment")
    public Result addComment(@RequestBody CommentDTO commentDTO) {
        Comment comment = new Comment();
        BeanUtils.copyProperties(commentDTO, comment);
        commentService.save(comment);
        return Result.success(true);
    }

    @GetMapping("/client/comment")
    public Result getCommentList(@RequestParam Integer articleId) {
        return Result.success(commentService.getArticleComment(articleId));
    }

    @GetMapping("/admin/comment")
    public Result getCommentPageList(@RequestParam Integer pageNum, @RequestParam Integer pageSize) {
        IPage<Comment> page = commentService.page(new Page<>(pageNum, pageSize));
        CommentListVO commentListVO = new CommentListVO((int)page.getTotal(), page.getRecords());
        return Result.success(commentListVO);
    }

    @DeleteMapping("/admin/comment")
    public Result deleteComment(@RequestParam Integer id) {
        Comment comment = commentService.getById(id);
        QueryWrapper<Comment> wrapper = new QueryWrapper<>();
        wrapper.eq("reply_id", comment.getId());
        commentService.remove(wrapper);
        commentService.removeById(id);
        return Result.success();
    }

    @PostMapping("/admin/comment")
    public Result replyComment(@RequestBody Comment comment) {
        commentService.save(comment);
        return Result.success();
    }

}
