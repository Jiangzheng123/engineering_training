package com.server.controller;


import com.server.common.Result;
import com.server.entity.WebInfo;
import com.server.service.IWebInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 网站信息表 前端控制器
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@RestController
public class WebInfoController {

    @Autowired
    IWebInfoService webInfoService;

    private static int webInfoID = 1;

    @GetMapping("/admin/webInfo")
    public Result webInfo() {
        WebInfo webInfo = webInfoService.getById(webInfoID);
        return Result.success(webInfo);
    }

    @PostMapping("/admin/webInfo")
    public Result updateWebInfo(@RequestBody WebInfo webInfo) {
        webInfoService.updateById(webInfo);
        return Result.success();
    }

}
