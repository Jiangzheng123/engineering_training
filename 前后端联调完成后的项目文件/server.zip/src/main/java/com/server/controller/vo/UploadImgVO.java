package com.server.controller.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 用于封装处理上传图片请求的返回数据
 * 暂时用不到
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UploadImgVO {
    String url;
}
