package com.server.controller.vo;

import com.server.entity.Label;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LabelListVO {
    private int total;
    private List<Label> records;
}
