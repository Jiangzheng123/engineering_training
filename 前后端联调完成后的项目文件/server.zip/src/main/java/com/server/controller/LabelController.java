package com.server.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.server.common.Constants;
import com.server.common.Result;
import com.server.controller.vo.LabelListVO;
import com.server.entity.ArticleLabel;
import com.server.entity.Label;
import com.server.exception.MyException;
import com.server.service.IArticleLabelService;
import com.server.service.ILabelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 标签表 前端控制器
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@RestController
public class LabelController {

    @Autowired
    ILabelService labelService;
    @Autowired
    IArticleLabelService articleLabelService;

    @GetMapping("/admin/label")
    public Result getLabel(@RequestParam int pageNum, @RequestParam int pageSize, @RequestParam String labelName) {
        IPage<Label> page = labelService.searchWithPage(pageNum, pageSize, labelName);
        LabelListVO labelListVO = new LabelListVO((int)page.getTotal(), page.getRecords());
        return Result.success(labelListVO);
    }

    @DeleteMapping("/admin/label")
    public Result deleteLabel(@RequestParam int id) {
        QueryWrapper<ArticleLabel> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("label_id", id);
        if(articleLabelService.count(queryWrapper)>0){
            throw new MyException(Constants.CODE_400, "有文章关联此标签");
        }else{
            labelService.removeById(id);
            return Result.success();
        }
    }

    @PostMapping("/admin/label")
    public Result saveLabel(@RequestBody Label label) {
        labelService.saveOrUpdate(label);
        return Result.success();
    }

    @GetMapping("/client/label")
    public Result getLabelList() {
        return Result.success(labelService.list());
    }
}
