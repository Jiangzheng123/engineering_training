package com.server.common;

public interface Constants {
    int CODE_200 = 200; // 请求成功
    int CODE_400 = 400; // 应用层的其它错误
    int CODE_401 = 401; // 登录相关错误
    int CODE_500 = 500; // 系统错误

    String MSG_200 = "请求成功";
    String MSG_500 = "系统错误";
}
