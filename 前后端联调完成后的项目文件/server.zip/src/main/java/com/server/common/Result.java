package com.server.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 接口统一返回包装类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Result {
    private int code;
    private String message;
    private Object data;

    public static Result success() {
        Result result = new Result();
        result.setCode(Constants.CODE_200);
        result.setMessage(Constants.MSG_200);
        return result;
    }

    public static Result success(Object data) {
        Result result = new Result();
        result.setCode(Constants.CODE_200);
        result.setMessage(Constants.MSG_200);
        result.setData(data);
        return result;
    }

    public static Result error(int code, String message) {
        Result result = new Result();
        result.setCode(code);
        result.setMessage(message);
        return result;
    }
}
