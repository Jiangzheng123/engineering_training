package com.server.common;

public class BaseContext {
    private static final ThreadLocal<Integer> currentId = new ThreadLocal<>();

    public static void setCurrentId(int id) {
        currentId.set(id);
    }

    public static int getCurrentId() {
        return currentId.get();
    }
}
