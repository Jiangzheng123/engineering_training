package com.server.mapper;

import com.server.entity.Image;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 图像表 Mapper 接口
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
public interface ImageMapper extends BaseMapper<Image> {

}
