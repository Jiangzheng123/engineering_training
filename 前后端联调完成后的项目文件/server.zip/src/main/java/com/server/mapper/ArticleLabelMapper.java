package com.server.mapper;

import com.server.entity.ArticleLabel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 文章与标签的对应表 Mapper 接口
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
public interface ArticleLabelMapper extends BaseMapper<ArticleLabel> {

}
