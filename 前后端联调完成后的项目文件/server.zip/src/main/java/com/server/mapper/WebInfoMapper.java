package com.server.mapper;

import com.server.entity.WebInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 网站信息表 Mapper 接口
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
public interface WebInfoMapper extends BaseMapper<WebInfo> {

}
