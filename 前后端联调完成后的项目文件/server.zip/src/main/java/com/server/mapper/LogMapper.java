package com.server.mapper;

import com.server.entity.Log;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 系统日志表 Mapper 接口
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
public interface LogMapper extends BaseMapper<Log> {

}
