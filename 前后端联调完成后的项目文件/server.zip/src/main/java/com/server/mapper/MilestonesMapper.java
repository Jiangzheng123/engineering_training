package com.server.mapper;

import com.server.entity.Milestones;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 里程碑表 Mapper 接口
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
public interface MilestonesMapper extends BaseMapper<Milestones> {

}
