package com.server.mapper;

import com.server.entity.Comment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 评论表 Mapper 接口
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
public interface CommentMapper extends BaseMapper<Comment> {

}
