package com.server.config;

import com.server.interceptor.JwtTokenInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 配置拦截器
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Autowired
    JwtTokenInterceptor jwtTokenInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // 注册JWT令牌拦截器
        registry.addInterceptor(jwtTokenInterceptor)
                .addPathPatterns("/**") // 拦截所有路径
                .excludePathPatterns("/admin/login", "/client/*", "/img/*");   // 除了管理端登录路径、用户端路径以及图片访问路径
    }
}
