package com.server.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.server.entity.Article;
import com.server.entity.Label;
import com.server.mapper.ArticleMapper;
import com.server.service.IArticleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.Synchronized;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 文章表 服务实现类
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@Service
public class ArticleServiceImpl extends ServiceImpl<ArticleMapper, Article> implements IArticleService {
    @Autowired
    private ArticleMapper articleMapper;

    @Override
    public IPage<Article> searchWithPage(int pageNum, int pageSize, String articleName) {
        Page<Article> page = new Page<>(pageNum, pageSize);
        QueryWrapper<Article> queryWrapper = new QueryWrapper<>();
        if(articleName != null && !"".equals(articleName)){
            queryWrapper.like("title", articleName);
        }
        return page(page, queryWrapper);
    }

    @Override
    public long getSumOfColumn(String columnName) {
        QueryWrapper<Article> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("SUM(" + columnName + ") as sum");
        Map<String, Object> map = articleMapper.selectMaps(queryWrapper).get(0);
        long sum = Long.parseLong(map.get("sum").toString());
        return sum;
    }

    @Override
    @Synchronized   // 为函数加锁，避免多个线程同时调用导致的数据冲突
    public void updateLikeNum(int articleId, int incrementNum) {
        UpdateWrapper<Article> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", articleId);
        updateWrapper.setSql("like_num = like_num + " + incrementNum);
        this.update(updateWrapper);
    }
}
