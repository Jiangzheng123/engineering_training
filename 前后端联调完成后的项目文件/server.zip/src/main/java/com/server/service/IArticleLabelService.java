package com.server.service;

import com.server.entity.ArticleLabel;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 文章与标签的对应表 服务类
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
public interface IArticleLabelService extends IService<ArticleLabel> {

}
