package com.server.service;

import com.server.entity.Log;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 系统日志表 服务类
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
public interface ILogService extends IService<Log> {

}
