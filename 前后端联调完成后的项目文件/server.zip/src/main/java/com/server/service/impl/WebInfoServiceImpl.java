package com.server.service.impl;

import com.server.entity.WebInfo;
import com.server.mapper.WebInfoMapper;
import com.server.service.IWebInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 网站信息表 服务实现类
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@Service
public class WebInfoServiceImpl extends ServiceImpl<WebInfoMapper, WebInfo> implements IWebInfoService {

}
