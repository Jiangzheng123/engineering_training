package com.server.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.server.entity.Image;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 图像表 服务类
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
public interface IImageService extends IService<Image> {

    IPage<Image> searchWithPage(int pageNum, int pageSize);
}
