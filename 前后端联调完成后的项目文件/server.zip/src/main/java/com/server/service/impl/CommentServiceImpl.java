package com.server.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.server.controller.vo.CommentVO;
import com.server.entity.Comment;
import com.server.mapper.CommentMapper;
import com.server.service.ICommentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 评论表 服务实现类
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@Service
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements ICommentService {

    @Override
    public List<CommentVO> getArticleComment(Integer id) {
        QueryWrapper<Comment> wrapper = new QueryWrapper<>();
        wrapper.eq("article_id", id);
        wrapper.eq("reply_id", 0);
        List<Comment> comments = this.list(wrapper);
        List<CommentVO> commentVOS = new ArrayList<>();
        for (Comment comment : comments) {
            CommentVO commentVO = new CommentVO();
            BeanUtils.copyProperties(comment, commentVO);
            commentVO.setChildren(getCommentChildren(comment.getId()));
            commentVOS.add(commentVO);
        }
        return commentVOS;
    }

    private List<CommentVO> getCommentChildren(int commentId) {
        QueryWrapper<Comment> wrapper = new QueryWrapper<>();
        wrapper.eq("reply_id", commentId);
        List<Comment> comments = this.list(wrapper);
        List<CommentVO> commentVOS = new ArrayList<>();
        for (Comment comment : comments) {
            CommentVO commentVO = new CommentVO();
            BeanUtils.copyProperties(comment, commentVO);
            commentVOS.add(commentVO);
        }
        return commentVOS;
    }
}
