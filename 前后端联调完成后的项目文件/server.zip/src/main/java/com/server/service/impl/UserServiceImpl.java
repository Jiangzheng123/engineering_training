package com.server.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.server.common.Constants;
import com.server.entity.User;
import com.server.exception.MyException;
import com.server.mapper.UserMapper;
import com.server.properties.JwtProperties;
import com.server.service.IUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.server.utils.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {
    @Autowired
    private JwtProperties jwtProperties;
    @Autowired
    private UserMapper userMapper;

    @Override
    public String login(String account, String password) {
        // 按条件查询
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("account", account);
        queryWrapper.eq("password", password);
        User user = userMapper.selectOne(queryWrapper);
        if(user == null){
            throw new MyException(Constants.CODE_400, "用户名或密码错误");
        }else{
            Map<String, Object> claims = new HashMap<>();
            claims.put("id", user.getId());
            claims.put("nickname", user.getNickname());
            String token = JwtUtil.createJWT(jwtProperties.getSecretKey(), jwtProperties.getTtl(), claims);
            return token;
        }
    }
}
