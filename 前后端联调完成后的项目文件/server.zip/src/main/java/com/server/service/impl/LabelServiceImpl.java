package com.server.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.server.entity.Label;
import com.server.mapper.LabelMapper;
import com.server.service.ILabelService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 标签表 服务实现类
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@Service
public class LabelServiceImpl extends ServiceImpl<LabelMapper, Label> implements ILabelService {

    @Autowired
    private LabelMapper labelMapper;

    @Override
    public IPage<Label> searchWithPage(int pageNum, int pageSize, String labelName) {
        Page<Label> page = new Page<>(pageNum, pageSize);
        QueryWrapper<Label> queryWrapper = new QueryWrapper<>();
        if(labelName != null && !"".equals(labelName)){
            queryWrapper.like("name", labelName);
        }
        return page(page, queryWrapper);
    }
}
