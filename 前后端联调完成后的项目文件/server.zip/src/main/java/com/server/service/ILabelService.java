package com.server.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.server.entity.Label;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 标签表 服务类
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
public interface ILabelService extends IService<Label> {

    IPage<Label> searchWithPage(int pageNum, int pageSize, String labelName);
}
