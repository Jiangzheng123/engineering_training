package com.server.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.server.entity.Article;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 文章表 服务类
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
public interface IArticleService extends IService<Article> {

    IPage<Article> searchWithPage(int pageNum, int pageSize, String articleName);

    long getSumOfColumn(String columnName);

    void updateLikeNum(int articleId, int incrementNum);
}
