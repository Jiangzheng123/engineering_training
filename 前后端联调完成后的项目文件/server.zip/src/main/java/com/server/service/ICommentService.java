package com.server.service;

import com.server.controller.vo.CommentVO;
import com.server.entity.Comment;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 评论表 服务类
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
public interface ICommentService extends IService<Comment> {

    List<CommentVO> getArticleComment(Integer id);
}
