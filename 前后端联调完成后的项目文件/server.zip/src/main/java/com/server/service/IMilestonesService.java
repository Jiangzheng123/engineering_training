package com.server.service;

import com.server.entity.Milestones;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 里程碑表 服务类
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
public interface IMilestonesService extends IService<Milestones> {

}
