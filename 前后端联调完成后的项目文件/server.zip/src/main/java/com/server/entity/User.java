package com.server.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.time.LocalDateTime;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 用户表
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@Getter
@Setter
@ApiModel(value = "User对象", description = "用户表")
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("用户id")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("用户账号")
    private String account;

    @ApiModelProperty("用户昵称")
    private String nickname;

    @ApiModelProperty("头像id，与image表的主键对应")
    private Integer imageId;

    @ApiModelProperty("用户密码")
    private String password;

    @ApiModelProperty("用户类型，0为管理者，1为普通用户，2为付费用户")
    private Integer type;

    @ApiModelProperty("创建时间，由MySQL自动填充即可")
    private LocalDateTime createdTime;


}
