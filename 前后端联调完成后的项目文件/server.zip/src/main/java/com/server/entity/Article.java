package com.server.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 文章表
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@Getter
@Setter
@ApiModel(value = "Article对象", description = "文章表")
public class Article implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("文章id")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("文章标题")
    private String title;

    @ApiModelProperty("文章简介")
    private String introduction;

    @ApiModelProperty("文章文本内容")
    private String content;

    @ApiModelProperty("文章版本号，默认为1")
    private Integer version;

    @ApiModelProperty("浏览数，默认为0")
    private Integer browseNum;

    @ApiModelProperty("评论数，默认为0")
    private Integer commentNum;

    @ApiModelProperty("点赞数，默认为0")
    private Integer likeNum;

    @ApiModelProperty("分享数，默认为0")
    private Integer shareNum;

    @ApiModelProperty("热度，默认为0")
    private Double heat;

    @ApiModelProperty("创建时间，由MySQL自动填充即可")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdTime;


}
