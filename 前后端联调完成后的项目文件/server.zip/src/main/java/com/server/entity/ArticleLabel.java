package com.server.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 文章与标签的对应表
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@Getter
@Setter
@TableName("article_label")
@ApiModel(value = "ArticleLabel对象", description = "文章与标签的对应表")
public class ArticleLabel implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("文章id")
    private Integer articleId;

    @ApiModelProperty("标签id")
    private Integer labelId;

    @ApiModelProperty("创建时间，由MySQL自动填充即可")
    private LocalDateTime createdTime;


}
