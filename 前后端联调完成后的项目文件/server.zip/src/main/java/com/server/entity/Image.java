package com.server.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 图像表
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@Getter
@Setter
@ApiModel(value = "Image对象", description = "图像表")
public class Image implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("图像id")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("图像类型，0代表用户头像，1代表文章配图")
    private Integer type;

    @ApiModelProperty("图片访问url")
    private String url;

    @ApiModelProperty("创建时间，由MySQL自动填充即可")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdTime;


}
