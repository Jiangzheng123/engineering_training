package com.server.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.time.LocalDateTime;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 里程碑表
 * </p>
 *
 * @author JiangZheng
 * @since 2024-10-25
 */
@Getter
@Setter
@ApiModel(value = "Milestones对象", description = "里程碑表")
public class Milestones implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("事件名")
    private String name;

    @ApiModelProperty("事件描述")
    private String description;

    @ApiModelProperty("创建时间，由MySQL自动填充即可")
    private LocalDateTime createdTime;

    @ApiModelProperty("里程碑id")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;


}
